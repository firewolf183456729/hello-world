<?php

namespace app\admin\controller\product\product;

use app\common\controller\Backend;
use think\Db;
use fast\Tree;

/**
 * 产品
 *
 * @icon fa fa-circle-o
 */
class Products extends Backend
{
    
    /**
     * Products模型对象
     * @var \app\admin\model\product\product\Products
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\product\product\Products;
        
        //分类
        $this->categorModel = new \app\admin\model\product\product\ProductCategory;
        // 必须将结果集转换为数组
        $categoryList = collection($this->categorModel->order('id', 'asc')->select())->toArray();
        // foreach ($categoryList as $k => &$v) {
        //     $v['title'] = __($v['chinese_name']);
        // }
        // unset($v);
        // Tree::instance()->init($categoryList);
        // $this->categoryList = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0), 'chinese_name');
        // $categorydata = [0 => __('请选择')];
        // foreach ($this->categoryList as $k => &$v) {

        //     $categorydata[$v['id']] = $v['chinese_name'];
        // }
        // unset($v);
        // // halt($channeldata);
        // $this->view->assign('categorydata', $categorydata);
        
        
        //产品自定义属性
        $product_custom_classification = Db::table('fa_product_custom_classification')->select();
        $this->view->assign('product_custom_classification', $product_custom_classification);
        
        //产品销售状态
        $sale_status = Db::table('fa_product_sale_status')->select();
        $this->view->assign('sale_status', $sale_status);
        

    }

    public function import()
    {
        parent::import();
    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
    /**
     * 查看
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                ->where($where)
                ->order($sort, $order)
                ->count();

            $list = $this->model
                ->where($where)
                ->order($sort, $order)
                ->limit($offset, $limit)
                ->select();
            //处理列表字段显示
            for($i=0;$i<count($list);$i++){
                //产品品类
                if($list[$i]['category_third']){
                    $list[$i]['category'] = Db::table('fa_product_category')->where('id',$list[$i]['category_third'])->value('chinese_name');
                }elseif(!$list[$i]['category_third'] && $list[$i]['category_second']){
                    $list[$i]['category'] = Db::table('fa_product_category')->where('id',$list[$i]['category_second'])->value('chinese_name');
                }elseif(!$list[$i]['category_third'] && !$list[$i]['category_second'] && $list[$i]['category_first']){
                    $list[$i]['category'] = Db::table('fa_product_category')->where('id',$list[$i]['category_first'])->value('chinese_name');
                }else{
                    $list[$i]['category'] = '';
                }
                // $list[$i]['category'] = $list[$i]['category'] > 0 ? Db::table('fa_product_category')->where('id',$list[$i]['category'])->value('chinese_name') : '';
                
                
                
                //产品自定义分类
                $product_custom_category = '';
                if($list[$i]['custom_classification']){
                    $pcc = explode(',',$list[$i]['custom_classification']);
                    for($j=0;$j<count($pcc);$j++){
                     $product_custom_category .= Db::table('fa_product_custom_classification')->where('id',$pcc[$j])->value('name').',';
                    }
                    $list[$i]['custom_classification'] = trim($product_custom_category,',');
                }else{
                    $list[$i]['custom_classification'] = '';
                }
                //产品颜色
                $list[$i]['color'] = $list[$i]['color'] > 0 ? Db::table('fa_product_color')->where('id',$list[$i]['color'])->value('color') : '';
                //产品尺码
                $list[$i]['size'] = $list[$i]['size'] > 0 ? Db::table('fa_product_size')->where('id',$list[$i]['size'])->value('size_name') : '';
                //产品单位
                $list[$i]['unit'] = $list[$i]['unit'] > 0 ? Db::table('fa_product_unit')->where('id',$list[$i]['unit'])->value('unit_name') : '';
                //产品等级
                $list[$i]['grade'] = $list[$i]['grade'] > 0 ? Db::table('fa_product_grade')->where('id',$list[$i]['grade'])->value('name') : '';
                //产品款式
                $list[$i]['style'] = $list[$i]['style'] > 0 ? Db::table('fa_product_style')->where('id',$list[$i]['style'])->value('name') : '';
                //产品品牌
                $list[$i]['brand'] = $list[$i]['brand'] > 0 ? Db::table('fa_product_brand')->where('id',$list[$i]['brand'])->value('name') : '';
                //产品物流属性
                $logistics = '';
                if($list[$i]['logistics']){
                    $las = explode(',',$list[$i]['logistics']);
                    for($j=0;$j<count($las);$j++){
                        $logistics .= Db::table('fa_product_logistics')->where('id',$las[$j])->value('name').',';
                    }
                    $list[$i]['logistics'] = trim($logistics,',');
                }else{
                    $list[$i]['$logistics'] = '';
                }
                //默认供应商
                $list[$i]['default_supplier'] = $list[$i]['default_supplier'] > 0 ? Db::table('fa_product_supplier')->where('id',$list[$i]['default_supplier'])->value('chinese_name') : '';
                //币种
                $list[$i]['currency'] = $list[$i]['currency'] > 0 ? Db::table('fa_currency')->where('id',$list[$i]['currency'])->value('name') : '';
                //仓库
                $list[$i]['warehouse'] = $list[$i]['warehouse'] > 0 ? Db::table('fa_product_warehouse')->where('id',$list[$i]['warehouse'])->value('warehouse_name') : '';
            }
            $list = collection($list)->toArray();
            $result = array("total" => $total, "rows" => $list);

            return json($result);
        }
        return $this->view->fetch();
    }
    /**
     * 添加
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);

                if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
                    $params[$this->dataLimitField] = $this->auth->id;
                }
                //处理产品分类参数
                $params['category_first'] = $this->request->post("")['first'];
                $params['category_second'] = $this->request->post("")['second'];
                $params['category_third'] = $this->request->post("")['third'];
                //判断category字段值
                if($params['category_third']){
                    $params['category'] = $params['category_third'];
                }elseif(!$params['category_third'] && $params['category_second']){
                    $params['category'] = $params['category_second'];
                }elseif(!$params['category_third'] && !$params['category_second'] && $params['category_first']){
                    $params['category'] = $params['category_first'];
                }else{
                    $params['category'] = '';
                }
    // halt($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                        $this->model->validateFailException(true)->validate($validate);
                    }
                    //处理特殊字段-自定义属性
                    $params['custom_classification'] = implode(",",$params['custom_classification']);
                    
                    
                    $result = $this->model->allowField(true)->save($params);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were inserted'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        return $this->view->fetch();
    }
    /**
     * 编辑
     */
    public function edit($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);
                //处理产品分类参数
                $params['category_first'] = $this->request->post("")['first'];
                $params['category_second'] = $this->request->post("")['second'];
                $params['category_third'] = $this->request->post("")['third'];
                //判断category字段值
                if($params['category_third']){
                    $params['category'] = $params['category_third'];
                }elseif(!$params['category_third'] && $params['category_second']){
                    $params['category'] = $params['category_second'];
                }elseif(!$params['category_third'] && !$params['category_second'] && $params['category_first']){
                    $params['category'] = $params['category_first'];
                }else{
                    $params['category'] = '';
                }
    // halt($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    //处理特殊字段-自定义属性
                    $params['custom_classification'] = implode(",",$params['custom_classification']);
                    
                    
                    
                    // die;
                    $result = $row->allowField(true)->save($params);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }
    
    /**
      * 重写backend中selectpage方法，从正确的model选择
      */
    public function get_product()
    {
         //设置过滤方法
         $this->request->filter(['strip_tags', 'htmlspecialchars']);

         //搜索关键词,客户端输入以空格分开,这里接收为数组
         $word = (array)$this->request->request("q_word/a");
         //当前页
         $page = $this->request->request("pageNumber");
         //分页大小
         $pagesize = $this->request->request("pageSize");
         //搜索条件
         $andor = $this->request->request("andOr", "and", "strtoupper");
         //排序方式
         $orderby = (array)$this->request->request("orderBy/a");
         //显示的字段
         $field = $this->request->request("showField");
         //主键
         $primarykey = $this->request->request("keyField");
         //主键值
         $primaryvalue = $this->request->request("keyValue");
         //搜索字段
         $searchfield = (array)$this->request->request("searchField/a");
         //自定义搜索条件
         $custom = (array)$this->request->request("custom/a");
         //是否返回树形结构
         $istree = $this->request->request("isTree", 0);
         $ishtml = $this->request->request("isHtml", 0);
         if ($istree) {
             $word = [];
             $pagesize = 99999;
         }
         $order = [];
         foreach ($orderby as $k => $v) {
             $order[$v[0]] = $v[1];
         }
         $field = $field ? $field : 'name';

         //如果有primaryvalue,说明当前是初始化传值
         if ($primaryvalue !== null) {
             $where = [$primarykey => ['in', $primaryvalue]];
             $pagesize = 99999;
         } else {
             $where = function ($query) use ($word, $andor, $field, $searchfield, $custom) {
                 $logic = $andor == 'AND' ? '&' : '|';
                 $searchfield = is_array($searchfield) ? implode($logic, $searchfield) : $searchfield;
                 foreach ($word as $k => $v) {
                     $query->where(str_replace(',', $logic, $searchfield), "like", "%{$v}%");
                 }
                 if ($custom && is_array($custom)) {
                     foreach ($custom as $k => $v) {
                         if (is_array($v) && 2 == count($v)) {
                             $query->where($k, trim($v[0]), $v[1]);
                         } else {
                             $query->where($k, '=', $v);
                         }
                     }
                 }
             };
         }
         $adminIds = $this->getDataLimitAdminIds();
         if (is_array($adminIds)) {
             $this->model->where($this->dataLimitField, 'in', $adminIds);
         }
         $list = [];
         $total = $this->model->where($where)->count();
         if ($total > 0) {
             if (is_array($adminIds)) {
                 $this->model->where($this->dataLimitField, 'in', $adminIds);
             }
             $datalist = $this->model->where($where)
 //                ->order($order)
                 ->order('id asc')
                 ->page($page, $pagesize)
                 ->field($this->selectpageFields)
                 ->select();
             foreach ($datalist as $index => $item) {
                 unset($item['password'], $item['salt']);
                 $list[] = [
                     $primarykey => isset($item[$primarykey]) ? $item[$primarykey] : '',
                     $field      => isset($item[$field]) ? $item[$field] : '',
                     'pid'       => isset($item['pid']) ? $item['pid'] : 0
                 ];
             }
             if ($istree && !$primaryvalue) {
                 $tree = Tree::instance();
                 $tree->init(collection($list)->toArray(), 'pid');
                 $list = $tree->getTreeList($tree->getTreeArray(0), $field);
                 if (!$ishtml) {
                     foreach ($list as &$item) {
                         $item = str_replace('&nbsp;', ' ', $item);
                     }
                     unset($item);
                 }
             }
         }
         //这里一定要返回有list这个字段,total是可选的,如果total<=list的数量,则会隐藏分页按钮
         return json(['list' => $list, 'total' => $total]);
    }
}
