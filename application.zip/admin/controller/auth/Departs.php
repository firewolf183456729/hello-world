<?php

namespace app\admin\controller\auth;

use app\common\controller\Backend;
use think\Db;
use fast\Random;
use fast\Tree;

/**
 * 部门管理
 *
 * @icon fa fa-circle-o
 */
class Departs extends Backend
{
    
    /**
     * Departs模型对象
     * @var \app\admin\model\auth\Departs
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = model('Admin');
        $this->departmodel = new \app\admin\model\auth\Departs;
        $this->assignconfig("admin", ['id' => $this->auth->id]);
        
        //部门数据
        $this->departmodel = new \app\admin\model\auth\Departs;
        $departList = collection($this->departmodel->order('id', 'asc')->select())->toArray();
        // halt($departList); 
        Tree::instance()->init($departList);
  
        $departdata = [];
        
        if ($this->auth->isSuperAdmin()) {
            $result2 = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0), 'dept_name');
            
            foreach ($result2 as $k2 => $v2) {
                $departdata[$v2['id']] = $v2['dept_name'];
            }
            // halt($departdata);
        } else {
            $result2 = [];
            $userid = Db::table('fa_admin')->where('id',$this->auth->id)->find()['userid'];
            // 执行查询
            $departs_groups = Db::table('fa_depart_access')
                ->alias('da')
                ->join('fa_departs d', 'da.depart_id = d.id')
                ->field('da.uid,da.depart_id,d.id,d.pid,d.dept_name')
                ->where("da.uid='{$userid}'")
                ->select();
    // halt($departs_groups);
            // $departs[$userid] = $departs_groups ?: [];
            foreach ($departs_groups as $m2 => $n2) {
                
                $childlist2 = Tree::instance()->getTreeList(Tree::instance()->getTreeArray($n2['id']));
                $temp2 = [];
                foreach ($childlist2 as $k2 => $v2) {
                    $temp2[$v2['id']] = $v2['dept_name'];
                }
                $result2[__($n2['dept_name'])] = $temp2;
            }
            $departdata = $result2;
        }
        $this->view->assign('departdata', $departdata);

    }

    public function import()
    {
        parent::import();
    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
    public function table1()
    {
        if ($this->request->isAjax()) {
            $List = collection($this->departmodel->order('id', 'asc')->select())->toArray();
            
            Tree::instance()->init($List);
            $List = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0), 'dept_name');
            foreach ($List as $k => &$v) {
                
                $List[$k][$v['id']] = $v['dept_name'];
            }
            unset($v);
            $total = count($List);
            $result = array("total" => $total, "rows" => $List);

            return json($result);
        }
        return $this->view->fetch();
    }
    public function table2()
    {
        $this->model = model('Admin');
        $departmodel = new \app\admin\model\auth\Departs;
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
        
            $depart_id = $departmodel->where($where)->find()['id'];
        
            $list = Db::table('fa_departs')
            ->alias('d')
			->join('fa_depart_access da','d.id = da.depart_id')
			->where('d.id',$depart_id)
			->order('da.uid desc')
			->field('da.uid')
			->select();
	
			$total = count($list);
            $List = [];
            for($i=0;$i<$total;$i++){
                // halt($list[$i]['uid']);  
                $List[$i] = Db::table('fa_admin')->where('userid',$list[$i]['uid'])->find();
            }
      
            $result = array("total" => $total, "rows" => $List);

            return json($result);
        }
        return $this->view->fetch('index');
    }
    /**
     * 删除
     */
    public function del($ids = "")
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ? $ids : $this->request->post("ids");
        // halt($ids);
        if ($ids) {
            $childlist = Db::table('fa_departs')->where('pid', $ids)->find();
            if($childlist){
                $this->error(__('不能删除含有子部门的部门'));
            }
            $res = Db::table('fa_departs')->where('id', $ids)->delete();
            Db::table('fa_depart_access')->where('depart_id', $ids)->delete();
            if ($res) {
                $this->success();
            } else {
                $this->error(__('No rows were deleted'));
            }
        }
        $this->error(__('Parameter %s can not be empty', 'ids'));
    }
    /**
     * 钉钉接口测试
     */
    public function ding()
    {
        //获取部门
        $this->get_departments();
        //获取角色组
        $this->get_getrolegroup();
        // //获取人员信息
        $res = $this->get_users();
        return $res;
    }
    /**
     * 钉钉测试access_token
     */
    public function get_access_token()
    {
        $headers = array(
            "Content-type:application/json;charset='utf-8'",
            "Accept:application/json",
        );
        //获取access_token
        $ch =curl_init(); //初始化
        curl_setopt($ch , CURLOPT_URL,"https://oapi.dingtalk.com/gettoken?appkey=dingegmttz4pbaypfwv1&appsecret=VsFGnsjVzj6MbrUuZMJco4O4B2gDJlpyTZjB-PeQadFtWsVOic66yswI4kBv1qdH");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        // curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);//不做服务器认证
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,0);//不做客户端认证
        $result = curl_exec($ch);//执行访问
        //返回一个包含当前会话错误信息的字符串
        if($error=curl_error($ch)){
            echo json_encode($error);
        }
        curl_close($ch);//关闭curl，释放资源
        $result = json_decode($result,true);
    // return $result;
        $access_token = $result['access_token'];
        return $access_token;
       
        
    }
    /**
     * 钉钉测试遍历获取所有部门
     */
    public function get_departments($dept_id = 1)
    {
        $access_token = $this->get_access_token();
        $headers = array(
            "Content-type:application/json;charset='utf-8'",
            "Accept:application/json",
        );
         //获取部门列表
        $ch2 =curl_init(); //初始化
        $postData2 = array(
            "language"   => "zh_CN",
            "dept_id"    => $dept_id
        );
        curl_setopt($ch2 , CURLOPT_URL,"https://oapi.dingtalk.com/topapi/v2/department/listsub?access_token=".$access_token);
        curl_setopt($ch2, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch2, CURLOPT_POSTFIELDS, json_encode($postData2));
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch2, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch2,CURLOPT_SSL_VERIFYPEER,FALSE);//不做服务器认证
        curl_setopt($ch2,CURLOPT_SSL_VERIFYHOST,0);//不做客户端认证
        $result2 = curl_exec($ch2);//执行访问
        //返回一个包含当前会话错误信息的字符串
        if($error2=curl_error($ch2)){
            echo json_encode($error2);
        }
        curl_close($ch2);//关闭curl，释放资源
        $result2 = json_decode($result2,true);
    // return $result2;
        $dept_list = $result2['result'];
        if(count($dept_list) > 0){
            for($i=0;$i<count($dept_list);$i++){
                $insertData['pid'] = $dept_list[$i]['parent_id'];
                $insertData['dept_id'] = $dept_list[$i]['dept_id'];
                $insertData['id'] = $dept_list[$i]['dept_id'];
                $insertData['dept_name'] = $dept_list[$i]['name'];
                
                $res = Db::table('fa_departs')->where('id',$insertData['dept_id'])->find();
                if(!$res){
                    $insertData['created'] = date('Y-m-d H:i:s',time());
                    $insertData['updated'] = date('Y-m-d H:i:s',time());
                    Db::table('fa_departs')->insertGetId($insertData);
                }else{
                    $insertData['updated'] = date('Y-m-d H:i:s',time());
                    Db::table('fa_departs')->where('id',$insertData['dept_id'])->update($insertData);
                }
                
                self::get_departments($dept_list[$i]['dept_id']);
            }
        }
        
        return $result2;
    }
    /**
     * 钉钉测试遍历获取所有部门用户userid列表
     */
    public function get_users()
    {
        $departsList = Db::table('fa_departs')->select();
        for($i=0;$i<count($departsList);$i++){
            $this->get_listid($departsList[$i]['id']);
        }
    }
    /**
     * 钉钉测试获取部门用户userid列表
     */
    public function get_listid($dept_id = 1)
    {
        $access_token = $this->get_access_token();
        $headers = array(
            "Content-type:application/json;charset='utf-8'",
            "Accept:application/json",
        );
         //获取部门用户userid列表
        $ch2 =curl_init(); //初始化
        $postData2 = array(
            "dept_id"   => $dept_id
        );
        curl_setopt($ch2 , CURLOPT_URL,"https://oapi.dingtalk.com/topapi/user/listid?access_token=".$access_token);
        curl_setopt($ch2, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch2, CURLOPT_POSTFIELDS, json_encode($postData2));
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch2, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch2,CURLOPT_SSL_VERIFYPEER,FALSE);//不做服务器认证
        curl_setopt($ch2,CURLOPT_SSL_VERIFYHOST,0);//不做客户端认证
        $result2 = curl_exec($ch2);//执行访问
        //返回一个包含当前会话错误信息的字符串
        if($error2=curl_error($ch2)){
            echo json_encode($error2);
        }
        curl_close($ch2);//关闭curl，释放资源
        $result2 = json_decode($result2,true);
        if(isset($result2['result']) && $result2['result']){
            $userIds = $result2['result']['userid_list'];
            $userList = [];
            for($i=0;$i<count($userIds);$i++){
                
                $userList['user_info'][$i] = $this->get_userinfo($userIds[$i]);   
                //查询用户是否已存在
                $res = Db::table('fa_admin')->where('userid',$userList['user_info'][$i]['result']['userid'])->find();
                $insertAdmin['nickname'] = $userList['user_info'][$i]['result']['name'];
                $insertAdmin['email'] = isset($userList['user_info'][$i]['result']['email']) ? $userList['user_info'][$i]['result']['email'] : '';
                $insertAdmin['avatar'] = $userList['user_info'][$i]['result']['avatar'];
                $insertAdmin['mobile'] = $userList['user_info'][$i]['result']['mobile'];
                $insertAdmin['title'] = isset($userList['user_info'][$i]['result']['title']) ? $userList['user_info'][$i]['result']['title'] : '';
                
                if($res){
                    $insertAdmin['updatetime'] = time();
                    $insertAdmin['unionid'] = $userList['user_info'][$i]['result']['unionid'];
                    Db::table('fa_admin')->where('userid',$userList['user_info'][$i]['result']['userid'])->update($insertAdmin);
                }else{
                    $insertAdmin['username'] = $userList['user_info'][$i]['result']['mobile'];
                    $insertAdmin['salt'] = Random::alnum();
                    $insertAdmin['password'] = md5(md5(123456) . $insertAdmin['salt']);
                    $insertAdmin['createtime'] = time();
                    $insertAdmin['updatetime'] = time();
                    $insertAdmin['userid'] = $userList['user_info'][$i]['result']['userid'];
                    $insertAdmin['unionid'] = $userList['user_info'][$i]['result']['unionid'];
                    
                    Db::table('fa_admin')->insertGetId($insertAdmin);
                }
                //所属角色组数据
                $role_list = isset($userList['user_info'][$i]['result']['role_list']) ? $userList['user_info'][$i]['result']['role_list'] : array();
                
                if(count($role_list) > 0){
                    Db::table('fa_auth_group_access')->where('uid',$userList['user_info'][$i]['result']['userid'])->delete();
                    for($j=0;$j<count($role_list);$j++){
                        $insertGroupAccess['uid'] = $userList['user_info'][$i]['result']['userid'];
                        $insertGroupAccess['group_id'] = $role_list[$j]['id'];
                        Db::table('fa_auth_group_access')->insertGetId($insertGroupAccess);
                    }
                }
                //所属部门数据
                $dept_list = isset($userList['user_info'][$i]['result']['dept_order_list']) ? $userList['user_info'][$i]['result']['dept_order_list'] : array();
                if(count($dept_list) > 0){
                    Db::table('fa_depart_access')->where('uid',$userList['user_info'][$i]['result']['userid'])->delete();
                    for($j=0;$j<count($dept_list);$j++){
                        $insertDeptAccess['uid'] = $userList['user_info'][$i]['result']['userid'];
                        $insertDeptAccess['depart_id'] = $dept_list[$j]['dept_id'];
                        $insertDeptAccess['createtime'] = time();
                        $insertDeptAccess['updatetime'] = time();
                        Db::table('fa_depart_access')->insertGetId($insertDeptAccess);
                    }
                }
                
                
            }
        }

    }
    /**
     * 钉钉测试获取在职员工详情
     */
    public function get_userinfo($user_id = '021544283430817846')
    {
        $access_token = $this->get_access_token();
        $headers = array(
            "Content-type:application/json;charset='utf-8'",
            "Accept:application/json",
        );
         //获取部门列表
        $ch2 =curl_init(); //初始化
        $postData2 = array(
            "language"  => "zh_CN",
            "userid"    => $user_id
        );
        curl_setopt($ch2 , CURLOPT_URL,"https://oapi.dingtalk.com/topapi/v2/user/get?access_token=".$access_token);
        curl_setopt($ch2, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch2, CURLOPT_POSTFIELDS, json_encode($postData2));
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch2, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch2,CURLOPT_SSL_VERIFYPEER,FALSE);//不做服务器认证
        curl_setopt($ch2,CURLOPT_SSL_VERIFYHOST,0);//不做客户端认证
        $result2 = curl_exec($ch2);//执行访问
        //返回一个包含当前会话错误信息的字符串
        if($error2=curl_error($ch2)){
            echo json_encode($error2);
        }
        curl_close($ch2);//关闭curl，释放资源
        $result2 = json_decode($result2,true);

        return $result2;
    }
    /**
     * 钉钉测试查询订阅事件
     */
    public function get_call_back()
    {
        $access_token = $this->get_access_token();
        $headers = array(
            "Content-type:application/json;charset='utf-8'",
            "Accept:application/json",
        );
         //获取部门列表
        $ch2 =curl_init(); //初始化
        // $postData2 = array(
        //     "language"  => "zh_CN",
        //     "userid"    => $user_id
        // );
        curl_setopt($ch2 , CURLOPT_URL,"https://oapi.dingtalk.com/call_back/get_call_back?access_token=".$access_token);
        curl_setopt($ch2, CURLOPT_CUSTOMREQUEST, "GET");
        // curl_setopt($ch2, CURLOPT_POSTFIELDS, json_encode($postData2));
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch2, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch2,CURLOPT_SSL_VERIFYPEER,FALSE);//不做服务器认证
        curl_setopt($ch2,CURLOPT_SSL_VERIFYHOST,0);//不做客户端认证
        $result2 = curl_exec($ch2);//执行访问
        //返回一个包含当前会话错误信息的字符串
        if($error2=curl_error($ch2)){
            echo json_encode($error2);
        }
        curl_close($ch2);//关闭curl，释放资源
        $result2 = json_decode($result2,true);

        return $result2;
    }
    /**
     * 钉钉测试获取角色组列表
     */
    public function get_getrolegroup()
    {
        $access_token = $this->get_access_token();
        $headers = array(
            "Content-type:application/json;charset='utf-8'",
            "Accept:application/json",
        );
         //获取部门列表
        $ch2 =curl_init(); //初始化
        $postData2 = array(
            "size"  => 20,
            "offset"    => 0
        );
        curl_setopt($ch2 , CURLOPT_URL,"https://oapi.dingtalk.com/topapi/role/list?access_token=".$access_token);
        curl_setopt($ch2, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch2, CURLOPT_POSTFIELDS, json_encode($postData2));
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch2, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch2,CURLOPT_SSL_VERIFYPEER,FALSE);//不做服务器认证
        curl_setopt($ch2,CURLOPT_SSL_VERIFYHOST,0);//不做客户端认证
        $result2 = curl_exec($ch2);//执行访问
        //返回一个包含当前会话错误信息的字符串
        if($error2=curl_error($ch2)){
            echo json_encode($error2);
        }
        curl_close($ch2);//关闭curl，释放资源
        $result2 = json_decode($result2,true);
// return $result2;
        //角色组数据
        if(isset($result2['result']) && $result2['result']){
            $authList = $result2['result']['list'];
            for($i=0;$i<count($authList);$i++){
                
                
                $insertData['pid'] = 1;
                $insertData['name'] = $authList[$i]['name'];
                $res = Db::table('fa_auth_group')->where('id',$authList[$i]['groupId'])->find();
                if($res){
                    $insertData['updatetime'] = time();
                    Db::table('fa_auth_group')->where('id',$authList[$i]['groupId'])->update($insertData);
                }else{
                    $insertData['id'] = $authList[$i]['groupId'];
                    $insertData['auth_id'] = $authList[$i]['groupId'];
                    $insertData['createtime'] = time();
                    $insertData['updatetime'] = time();
                    Db::table('fa_auth_group')->insertGetId($insertData);
                }
                if(count($authList[$i]['roles']) > 0){
                    $authList2 = $authList[$i]['roles'];
                    $insertData2['pid'] = $authList[$i]['groupId'];
                    for($j=0;$j<count($authList2);$j++){
                        
                        $insertData2['name'] = $authList2[$j]['name'];
                        $res2 = Db::table('fa_auth_group')->where('id',$authList2[$j]['id'])->find();
                        
                        if($res2){
                            $insertData2['updatetime'] = time();
                            Db::table('fa_auth_group')->where('id',$authList2[$j]['id'])->update($insertData2);
                        }else{
                            $insertData2['id'] = $authList2[$j]['id'];
                            $insertData2['auth_id'] = $authList2[$j]['id'];
                            $insertData2['createtime'] = time();
                            $insertData2['updatetime'] = time();
                            Db::table('fa_auth_group')->insertGetId($insertData2);
                        }
                    }
                }
            }
        }

        // return $result2;
    }

}
