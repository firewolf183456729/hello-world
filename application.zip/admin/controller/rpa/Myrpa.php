<?php

namespace app\admin\controller\rpa;

use app\common\controller\Backend;
use think\Db;

/**
 * 我的RPA
 *
 * @icon fa fa-circle-o
 */
class Myrpa extends Backend
{
    
    /**
     * Myrpa模型对象
     * @var \app\admin\model\rpa\Myrpa
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\rpa\Myrpa;

    }

    public function import()
    {
        parent::import();
    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
    /**
     * 查看
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();

            $list = $this->model
                ->where($where)
                ->order($sort, $order)
                ->paginate($limit);
            
            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
     
    }
    /**
     *实时更新
     */
    public function get_rpa_details()
    {
        $id = input('ids');
        $rpaIdList = [];
        $rpa_info = Db::table('fa_myrpa')->where('id',$id)->where('active',1)->find();
        array_push($rpaIdList,$rpa_info['rpa_id']);
        $startTime = date('Y-m-d 00:00:00',time()-24*60*60);
        $endTime = date('Y-m-d H:i:s',time());
//        echo $rpa_id.'--'.$startTime.'--'.$endTime;die;
        $headers = array(
            "Content-type:application/json;charset='utf-8'",
            "Accept:application/json",
            'token:3ed3eefa-8e04-4f9d-9945-f433b1ee3c3b'
        );
        $postData = array(
            "rpaIdList" => $rpaIdList,
            "startTime" => $startTime,
            "endTime"   => $endTime,
            "page"      => 1,
            "limit"     => 500
        );
        $ch =curl_init(); //初始化
        curl_setopt($ch , CURLOPT_URL,"https://rpa-server.ziniao.com/erp_report/list");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);//不做服务器认证
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,0);//不做客户端认证
        $result = curl_exec($ch);//执行访问
        //返回一个包含当前会话错误信息的字符串
        if($error=curl_error($ch)){
            echo json_encode($error);
        }
        curl_close($ch);//关闭curl，释放资源
//        echo $result;die;
        $result = json_decode($result,true);

        $rpa_datas = $result['data']['result'];
        
        for($i=0;$i<count($rpa_datas);$i++){
            //查重
            $runData = Db::table('fa_rpa_details')->where('rpa_id',$rpa_datas[$i]['rpaId'])->where('run_id',$rpa_datas[$i]['id'])->find();
            if($runData){
                continue;
            }
            $insertData['run_id'] = $rpa_datas[$i]['id'];
            $insertData['rpa_id'] = $rpa_datas[$i]['rpaId'];
            $insertData['url'] = urldecode($rpa_datas[$i]['url']);
            $insertData['run_name'] = urldecode($rpa_datas[$i]['name']);
            $insertData['rpa_name'] = $rpa_datas[$i]['rpaName'];
            $insertData['store_name'] = $rpa_datas[$i]['storeName'];
            $insertData['site_name'] = $rpa_datas[$i]['siteName'];
            $insertData['site_name_en'] = $rpa_datas[$i]['siteNameEn'];
            $insertData['platform_type'] = $rpa_datas[$i]['platformType'];
            $insertData['start_time'] = date('Y-m-d H:i:s',strtotime($rpa_datas[$i]['startTime']));
            $insertData['end_time'] = date('Y-m-d H:i:s',strtotime($rpa_datas[$i]['endTime']));
            $insertData['finish_time'] = date('Y-m-d H:i:s',strtotime($rpa_datas[$i]['finishTime']));
            $insertData['seller_id'] = $rpa_datas[$i]['sellerId'];
            $insertData['marketplace_id'] = $rpa_datas[$i]['marketplaceId'];
            Db::table('fa_rpa_details')->insertGetId($insertData);
        }
        $data['code'] = 1;
        $data['msg'] = 'Success!';
        echo json_encode($data);
    }
    

}
