<?php

namespace app\admin\controller\marketing;

use app\common\controller\Backend;
use think\Db;
use fast\Tree;
use Exception;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xls;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use PhpOffice\PhpSpreadsheet\Helper\Sample;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx AS Xlsx2;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;

/**
 * 红人信息
 *
 * @icon fa fa-circle-o
 */
class Hongren extends Backend
{
    
    /**
     * Hongren模型对象
     * @var \app\admin\model\marketing\Hongren
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\marketing\Hongren;
        $this->view->assign("gradeList", $this->model->getGradeList());
        $this->view->assign("cooperationProgressList", $this->model->getCooperationProgressList());
        $this->view->assign("genderList", $this->model->getGenderList());
        //平台
        $platformModel = new \app\admin\model\marketing\Platform;
        // 必须将结果集转换为数组
        $platformList = collection($platformModel->order('id', 'asc')->select())->toArray();
     
        $platformdata = [0 => __('选择')];
        foreach ($platformList as $k => &$v) {
            
            $platformdata[$v['id']] = $v['name'];
        }
        unset($v);
        $this->view->assign('platformdata', $platformdata);
        $this->assignconfig('platformdata', $platformdata);
    }

   

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
    /**
     * 查看
     */
    public function index()
    {
        $hr = isset($_GET['hr']) ? $_GET['hr'] : '';
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            if($hr != ''){
                $list = $this->model
                    ->where($where)
                    ->where('name',$hr)
                    ->order($sort, $order)
                    ->paginate($limit);
            }else{
                $list = $this->model
                    ->where($where)
                    ->order($sort, $order)
                    ->paginate($limit);
            }
            for($i=0;$i<count($list);$i++){
                $list[$i]['createtime'] = date('Y-m-d H:i:s',$list[$i]['createtime']);
                $list[$i]['updatetime'] = date('Y-m-d H:i:s',$list[$i]['updatetime']);
            }
            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }
    /**
     * 添加
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);
// halt($params);
                $insertData['name']                 = $params['name'];
                $insertData['grade']                = $params['grade'];
                $insertData['cooperation_project']  = $params['cooperation_project'];
                $insertData['cooperation_num']      = $params['cooperation_num'];
                $insertData['release_links']        = $params['release_links'];
                $insertData['cooperation_progress'] = $params['cooperation_progress'];
                $insertData['country']              = $params['country'];
                $insertData['email']                = $params['email'];
                $insertData['gender']               = $params['gender'];
                $insertData['age']                  = $params['age'];
                $insertData['main_category']        = $params['main_category'];
                $insertData['money']                = $params['money'];
                $insertData['receiving']            = $params['receiving'];
                $insertData['receive_address']      = $params['receive_address'];
                $insertData['phone']                = $params['phone'];
                $insertData['contact']              = $params['contact'];
                $insertData['remark']               = $params['remark'];
                $insertData['createtime']           = time();
                $insertData['updatetime']           = time();
                $platform_data                      = [];
                if(isset($params['platform']) && count($params['platform']) > 0){
                    for($i=0;$i<count($params['platform']);$i++){
                        $extendData['platform']   = $params['platform'][$i];
                        $extendData['fans_num']   = $params['fans_num'][$i];
                        $extendData['link']       = $params['link'][$i];
                        $release_links = trim($params['release_links'][$i]);
                        $release_links = explode("\r\n",$release_links);
    // halt($params);
                        //去空格
                        foreach ($release_links as $k => $v)
                        {
                            $key[$k] = trim($v);
                        }
                        $release_links = implode(',',$release_links);
                        $extendData['release_links']  = $release_links;
        // halt($release_links);
                        $platform_data[]          = $extendData;
                    }
                }
                $insertData['platform_data'] = count($platform_data) > 0 ? json_encode($platform_data) : '';
                $id = Db::table('fa_hongren')->insertGetId($insertData);
                if($id){
                    $this->success();
                }else{
                    $this->error(__('No rows were inserted'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        return $this->view->fetch();
    }
    /**
     * 编辑
     */
    public function edit($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            // halt($params);
            if ($params) {
                // $params = $this->preExcludeFields($params);
    // halt($ids);
                $insertData['name']                 = $params['name'];
                $insertData['grade']                = $params['grade'];
                $insertData['cooperation_project']  = $params['cooperation_project'];
                $insertData['cooperation_num']      = $params['cooperation_num'];
                $insertData['release_links']        = $params['release_links'];
                $insertData['cooperation_progress'] = $params['cooperation_progress'];
                $insertData['country']              = $params['country'];
                $insertData['email']                = $params['email'];
                $insertData['gender']               = $params['gender'];
                $insertData['age']                  = $params['age'];
                $insertData['main_category']        = $params['main_category'];
                $insertData['money']                = $params['money'];
                $insertData['receiving']            = $params['receiving'];
                $insertData['receive_address']      = $params['receive_address'];
                $insertData['phone']                = $params['phone'];
                $insertData['contact']              = $params['contact'];
                $insertData['remark']               = $params['remark'];
                $insertData['updatetime']           = time();
                $platform_data                      = [];
                
                // halt($params['fblink']);
                if(isset($params['platform']) && count($params['platform']) > 0){
                    for($i=0;$i<count($params['platform']);$i++){
                        $extendData['platform']   = $params['platform'][$i];
                        $extendData['fans_num']   = $params['fans_num'][$i];
                        $extendData['link']       = $params['link'][$i];
                        $release_links = trim($params['release_links'][$i]);
                        $release_links = explode("\r\n",$release_links);
                        //去空格
                        foreach ($release_links as $k => $v)
                        {
                            $key[$k] = trim($v);
                        }
                        $release_links = implode(',',$release_links);
                        $extendData['release_links']  = $release_links;
                        $platform_data[]          = $extendData;
                    }
                }
                $insertData['platform_data']           = count($platform_data) > 0 ? json_encode($platform_data) : '';
                $res = Db::table('fa_hongren')->where('id',$ids)->update($insertData);
                $this->success();

            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $extendData = json_decode($row['platform_data'],true);
        // halt($extendData);
        for($i=0;$i<count($extendData);$i++){
            if(isset($extendData[$i]['release_links']) && $extendData[$i]['release_links']){
                $extendData[$i]['release_links'] = explode(",",$extendData[$i]['release_links']);
                $extendData[$i]['release_links'] = implode("\r\n",$extendData[$i]['release_links']);
            }else{
                $extendData[$i]['release_links'] = '';
            
            }
            
        }
        $this->view->assign("row", $row);
        $this->view->assign("extendData", $extendData);
        return $this->view->fetch();
    }
    /**
     * 导入
     */
    public function import()
    {
        $file = $this->request->request('file');
        if (!$file) {
            $this->error(__('Parameter %s can not be empty', 'file'));
        }
        $filePath = ROOT_PATH . DS . 'public' . DS . $file;
        if (!is_file($filePath)) {
            $this->error(__('No results were found'));
        }
        //实例化reader
        $ext = pathinfo($filePath, PATHINFO_EXTENSION);
        if (!in_array($ext, ['csv', 'xls', 'xlsx'])) {
            $this->error(__('Unknown data format'));
        }
        if ($ext === 'csv') {
            $file = fopen($filePath, 'r');
            $filePath = tempnam(sys_get_temp_dir(), 'import_csv');
            $fp = fopen($filePath, "w");
            $n = 0;
            while ($line = fgets($file)) {
                $line = rtrim($line, "\n\r\0");
                $encoding = mb_detect_encoding($line, ['utf-8', 'gbk', 'latin1', 'big5']);
                if ($encoding != 'utf-8') {
                    $line = mb_convert_encoding($line, 'utf-8', $encoding);
                }
                if ($n == 0 || preg_match('/^".*"$/', $line)) {
                    fwrite($fp, $line . "\n");
                } else {
                    fwrite($fp, '"' . str_replace(['"', ','], ['""', '","'], $line) . "\"\n");
                }
                $n++;
            }
            fclose($file) || fclose($fp);

            $reader = new Csv();
        } elseif ($ext === 'xls') {
            $reader = new Xls();
        } else {
            $reader = new Xlsx();
        }

        //导入文件首行类型,默认是注释,如果需要使用字段名称请使用name
        $importHeadType = isset($this->importHeadType) ? $this->importHeadType : 'comment';

        $table = $this->model->getQuery()->getTable();
        $database = \think\Config::get('database.database');
        $fieldArr = [];
        $list = db()->query("SELECT COLUMN_NAME,COLUMN_COMMENT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ? AND TABLE_SCHEMA = ?", [$table, $database]);
        foreach ($list as $k => $v) {
            if ($importHeadType == 'comment') {
                $fieldArr[$v['COLUMN_COMMENT']] = $v['COLUMN_NAME'];
            } else {
                $fieldArr[$v['COLUMN_NAME']] = $v['COLUMN_NAME'];
            }
        }

        //加载文件
        $insert = [];
        try {
            if (!$PHPExcel = $reader->load($filePath)) {
                $this->error(__('Unknown data format'));
            }
            $currentSheet = $PHPExcel->getSheet(0);  //读取文件中的第一个工作表
            $allColumn = $currentSheet->getHighestDataColumn(); //取得最大的列号

            $allRow = $currentSheet->getHighestRow(); //取得一共有多少行

            $maxColumnNumber = Coordinate::columnIndexFromString($allColumn);
            $fields = [];
            for ($currentRow = 1; $currentRow <= 1; $currentRow++) {
                for ($currentColumn = 1; $currentColumn <= $maxColumnNumber; $currentColumn++) {
                    $val = $currentSheet->getCellByColumnAndRow($currentColumn, $currentRow)->getValue();
                    $fields[] = $val;
                }
            }

            for ($currentRow = 2; $currentRow <= $allRow; $currentRow++) {
                $values = [];
                for ($currentColumn = 1; $currentColumn <= $maxColumnNumber; $currentColumn++) {
                    $val = $currentSheet->getCellByColumnAndRow($currentColumn, $currentRow)->getValue();
                    $values[] = is_null($val) ? '' : $val;
                }
                $row = [];
                $temp = array_combine($fields, $values);
    
    
// halt($temp);    
    
                foreach ($temp as $k => $v) {
                    
                    if (isset($fieldArr[$k]) && $k !== '') {
                       
                        $row[$fieldArr[$k]] = $v;
                    }
                }
                //拼接platform_data数据
                $extendData['platform']   = Db::table('fa_platform')->where('name',$temp['平台'])->find()['id'];
                $extendData['fans_num']   = $temp['粉丝数量'];
                $extendData['link']       = $temp['链接'];
                $extendData['release_links']       = $temp['发布链接'];
                if($temp['平台'] != '' || $temp['粉丝数量'] != '' || $temp['链接'] != '' || $temp['发布链接'] != ''){
                    $row['platform_data'] = $extendData;
                }else{
                    $row['platform_data'] = [];
                }
                
                $row['createtime'] = date('Y-m-d H:i:s',time());
                $row['updatetime'] = date('Y-m-d H:i:s',time());
    // halt($row);
                if ($row) {
                    $insert[] = $row;
                }
            }
        } catch (Exception $exception) {
            $this->error($exception->getMessage());
        }
        if (!$insert) {
            $this->error(__('No rows were updated'));
        }

        try {
            //是否包含admin_id字段
            $has_admin_id = false;
            foreach ($fieldArr as $name => $key) {
                if ($key == 'admin_id') {
                    $has_admin_id = true;
                    break;
                }
            }
            if ($has_admin_id) {
                $auth = Auth::instance();
                foreach ($insert as &$val) {
                    if (!isset($val['admin_id']) || empty($val['admin_id'])) {
                        $val['admin_id'] = $auth->isLogin() ? $auth->id : 0;
                    }
                }
            }  
            for($i=0;$i<count($insert);$i++){
                $name = $insert[$i]['name'];
                unset($insert[$i]['id']);
                //查询是否存在
                $find = Db::table('fa_hongren')->where('name',$name)->find();
                
                if($find){
                    //旧platform_data数据
                    $platform_data = json_decode($find['platform_data'],true);
                    //拼接新platform_data数据
                    if(count($insert[$i]['platform_data']) > 0){
                        $isset = 0;
                        for($n=0;$n<count($platform_data);$n++){
                            if($platform_data[$n]['link'] == $insert[$i]['platform_data']['link']){
                                $platform_data[$n]['platform'] = $insert[$i]['platform_data']['platform'];
                                $platform_data[$n]['fans_num'] = $insert[$i]['platform_data']['fans_num'];
                                $platform_data[$n]['link'] = $insert[$i]['platform_data']['link'];
                                $platform_data[$n]['release_links'] = $insert[$i]['platform_data']['release_links'];
                                $isset = 1;
                            }
                        }
                        if($isset == 0){
                            array_push($platform_data,$insert[$i]['platform_data']);
                        }
                        
                    }
                    
                    $insert[$i]['platform_data'] = json_encode($platform_data);
                    // halt($insert); 
                    Db::table('fa_hongren')->where('name',$name)->update($insert[$i]);
                }else{
                    $insert[$i]['platform_data'] = json_encode(array($insert[$i]['platform_data']));
                    // halt($insert); 
                    Db::table('fa_hongren')->insertGetId($insert[$i]);
                }
            }
            // $this->model->saveAll($insert);
        } catch (PDOException $exception) {
            $msg = $exception->getMessage();
            if (preg_match("/.+Integrity constraint violation: 1062 Duplicate entry '(.+)' for key '(.+)'/is", $msg, $matches)) {
                $msg = "导入失败，包含【{$matches[1]}】的记录已存在";
            };
            $this->error($msg);
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }

        $this->success();
    }
    /**
     * 导出
     */
    public function export()
    {
        if ($this->request->isPost()) {
            set_time_limit(0);
            $search = $this->request->post('search');
            $ids = $this->request->post('ids');
            $filter = $this->request->post('filter');
            $op = $this->request->post('op');
            $columns = $this->request->post('columns');

            //$excel = new PHPExcel();
            $spreadsheet = new Spreadsheet();

            $spreadsheet->getProperties()
                ->setCreator("FastAdmin")
                ->setLastModifiedBy("FastAdmin")
                ->setTitle("标题")
                ->setSubject("Subject");
            $spreadsheet->getDefaultStyle()->getFont()->setName('Microsoft Yahei');
            $spreadsheet->getDefaultStyle()->getFont()->setSize(12);

            $worksheet = $spreadsheet->setActiveSheetIndex(0);
            $whereIds = $ids == 'all' ? '1=1' : ['id' => ['in', explode(',', $ids)]];
            $this->request->get(['search' => $search, 'ids' => $ids, 'filter' => $filter, 'op' => $op]);
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            
            $line = 1;

            //设置过滤方法
            $this->request->filter(['strip_tags']);

            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                ->where($whereIds)
                ->where($where)
                ->order($sort, $order)
                ->count();

            $list = $this->model
                ->where($whereIds)
                ->where($where)
                ->order($sort, $order)
                ->limit($offset, $limit)
                ->select();

            $list = collection($list)->toArray();
            $result = array("total" => $total, "rows" => $list);
            
            $first = array_keys($list[0]);
            foreach ($first as $index => $item) {
                $worksheet->setCellValueByColumnAndRow($index, 1, __($item));
            }
            
            $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load(__DIR__ . '/muban/hr_output.xls');  //读取模板
            $worksheet = $spreadsheet->getActiveSheet();     //指向激活的工作表
            $worksheet->setTitle('红人信息');

            //可以先设置表头
            $worksheet->getCell('A1')->setValue('ID');
            $worksheet->getCell('B1')->setValue('红人姓名');
            $worksheet->getCell('C1')->setValue('评级');
            $worksheet->getCell('D1')->setValue('合作项目');
            $worksheet->getCell('E1')->setValue('合作次数');
            $worksheet->getCell('F1')->setValue('合作进度');
            $worksheet->getCell('G1')->setValue('国家');
            $worksheet->getCell('H1')->setValue('邮箱');
            $worksheet->getCell('I1')->setValue('性别');
            $worksheet->getCell('J1')->setValue('年龄');
            $worksheet->getCell('K1')->setValue('主要类目');
            $worksheet->getCell('L1')->setValue('报价');
            $worksheet->getCell('M1')->setValue('收件人');
            $worksheet->getCell('N1')->setValue('收件地址');
            $worksheet->getCell('O1')->setValue('手机号');
            $worksheet->getCell('P1')->setValue('备注');
            $worksheet->getCell('Q1')->setValue('联系人');
            $worksheet->getCell('R1')->setValue('平台');
            $worksheet->getCell('S1')->setValue('粉丝数量');
            $worksheet->getCell('T1')->setValue('链接');
            $worksheet->getCell('U1')->setValue('发布链接');
// halt($result['rows']);
            $current_row = 2;
            for($i=0;$i<$total;++$i){ 
                $platformData = $result['rows'][$i]['platform_data'];
                if($platformData == ''){
                    $num = 0;
                }else{
                    $num = count(json_decode($platformData,true));
                }
                if($num <= 1){
                    $num = 1;
                }
                //向模板表中写入数据
                for($j=0;$j<$num;$j++){
                    $worksheet->getCell('A'.$current_row)->setValue($result['rows'][$i]['id']);
                    $worksheet->getCell('B'.$current_row)->setValue($result['rows'][$i]['name']);
                    $worksheet->getCell('C'.$current_row)->setValue($result['rows'][$i]['grade']);
                    $worksheet->getCell('D'.$current_row)->setValue($result['rows'][$i]['cooperation_project']);
                    $worksheet->getCell('E'.$current_row)->setValue($result['rows'][$i]['cooperation_num']);
                    $worksheet->getCell('F'.$current_row)->setValue($result['rows'][$i]['cooperation_progress']);
                    $worksheet->getCell('G'.$current_row)->setValue($result['rows'][$i]['country']);
                    $worksheet->getCell('H'.$current_row)->setValue($result['rows'][$i]['email']);
                    $worksheet->getCell('I'.$current_row)->setValue($result['rows'][$i]['gender']);
                    $worksheet->getCell('J'.$current_row)->setValue($result['rows'][$i]['age']);
                    $worksheet->getCell('K'.$current_row)->setValue($result['rows'][$i]['main_category']);
                    $worksheet->getCell('L'.$current_row)->setValue($result['rows'][$i]['money']);
                    $worksheet->getCell('M'.$current_row)->setValue($result['rows'][$i]['receiving']);
                    $worksheet->getCell('N'.$current_row)->setValue($result['rows'][$i]['receive_address']);
                    $worksheet->getCell('O'.$current_row)->setValue($result['rows'][$i]['phone']);
                    $worksheet->getCell('P'.$current_row)->setValue($result['rows'][$i]['remark']);
                    $worksheet->getCell('Q'.$current_row)->setValue($result['rows'][$i]['contact']);
                    if($platformData != '' && count(json_decode($platformData,true)) > 0){
                        $pf = Db::table('fa_platform')->where('id',json_decode($platformData,true)[$j]['platform'])->find()['name'];
                        $worksheet->getCell('R'.$current_row)->setValue($pf ? $pf : '');
                        $worksheet->getCell('S'.$current_row)->setValue(json_decode($platformData,true)[$j]['fans_num']);
                        $worksheet->getCell('T'.$current_row)->setValue(json_decode($platformData,true)[$j]['link']);
                        $worksheet->getCell('U'.$current_row)->setValue(json_decode($platformData,true)[$j]['release_links']);
                    }else{
                        $worksheet->getCell('R'.$current_row)->setValue('');
                        $worksheet->getCell('S'.$current_row)->setValue('');
                        $worksheet->getCell('T'.$current_row)->setValue('');
                        $worksheet->getCell('U'.$current_row)->setValue('');
                    }
                    $current_row += 1;
                }
                
            } 
    // halt($spreadsheet); 
            $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xls');
            //下载文档
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="'. date('Y-m-d') . 'hr_output.xlsx"');
            header('Cache-Control: max-age=0');
            $writer = new Xlsx2($spreadsheet);
            $writer->save('php://output');      

            return;
        }
    }


}
