<?php

namespace app\admin\controller\feedback\amazon;

use app\common\controller\Backend;
use Exception;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xls;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use think\Db;
use think\exception\PDOException;
use think\exception\ValidateException;
use app\admin\library\Auth;

/**
 * Amazon Feedback
 *
 * @icon fa fa-circle-o
 */
class Feedback extends Backend
{
    
    /**
     * Feedback模型对象
     * @var \app\admin\model\feedback\amazon\Feedback
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\feedback\amazon\Feedback;
        $this->view->assign("ticketReappealedList", $this->model->getTicketReappealedList());
        $this->view->assign("removedList", $this->model->getRemovedList());
        $this->view->assign("reviewedList", $this->model->getReviewedList());
        
        //index页tab
        $follow_count['new'] = Db::table('fa_amazon_feedback')->where('follow_status','new')->count();
        $follow_count['pending'] = Db::table('fa_amazon_feedback')->where('follow_status','pending')->count();
        $follow_count['closed'] = Db::table('fa_amazon_feedback')->where('follow_status','closed')->count();
        $follow_count['expired'] = Db::table('fa_amazon_feedback')->where('follow_status','expired')->count();
        $follow_count['reviewed'] = Db::table('fa_amazon_feedback')->where('reviewed','>',0)->count();
        $this->view->assign("follow_count",$follow_count);
        //判断用户是否有权限显示相应按钮
        //用户的userid
        $userid = Db::table('fa_admin')->where('id',$this->auth->id)->find()['userid'];
        //用户的角色id
        $group_ids = Db::table('fa_auth_group_access')->where('uid',$userid)->select();
        if(count($group_ids) > 0){
            $show['review'] = 0;
            $show['request_removal'] = 0;
            $show['change_follower'] = 0;
            for($i=0;$i<count($group_ids);$i++){
                $re1 = Db::table('fa_auth_group')->where('id',$group_ids[$i]['group_id'])->where('find_in_set(525,rules)')->find();
                $re2 = Db::table('fa_auth_group')->where('id',$group_ids[$i]['group_id'])->where('find_in_set(526,rules)')->find();
                $re3 = Db::table('fa_auth_group')->where('id',$group_ids[$i]['group_id'])->where('find_in_set(527,rules)')->find();
                // var_dump($re1);
                if($re1 || $this->auth->id == 1){
                    $show['change_follower'] = 1;
                }
                if($re2 || $this->auth->id == 1){
                    $show['request_removal'] = 1;
                }
                if($re3 || $this->auth->id == 1){
                    $show['review'] = 1;
                }
            }
        }
        $this->assignconfig("show", $show);
    }


    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
     
    /**
     * 查看
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $params = $this->request->get('');
//   halt($where); 

            $list = $this->model
                    ->where($where)
                    ->order($sort, $order)
                    ->paginate($limit);
            for($i=0;$i<count($list);$i++){
                
                $list[$i]['followed_by'] = Db::table('fa_admin')->where('id',$list[$i]['followed_by'])->find()['nickname'];
            }

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }
    /**
     * 添加
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);
// halt($params);
                if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
                    $params[$this->dataLimitField] = $this->auth->id;
                }
                $params['added_on'] = date('Y-m-d H:i:s',time());
                $params['added_by'] = Db::table('fa_admin')->where('id',$this->auth->id)->find()['nickname'];
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                        $this->model->validateFailException(true)->validate($validate);
                    }
                    $result = $this->model->allowField(true)->save($params);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were inserted'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        return $this->view->fetch();
    }
    /**
     * detail详情
     */
    public function details($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    $oldData =  Db::table('fa_amazon_feedback')->where('id',$ids)->find();
                    $result = $row->allowField(true)->save($params);
                    //添加日志
                    if($params['follow_status'] != $oldData['follow_status']){
                        $this->add_logs($ids,'amazon','Update follow status from '.$oldData['follow_status'].' to '.$params['follow_status']);
                    }
                    if($params['reason'] != $oldData['reason']){
                        $old_reason = Db::table('fa_ebay_feedback_reason')->where('id',$oldData['reason'])->find()['name'];
                        $new_reason = Db::table('fa_ebay_feedback_reason')->where('id',$params['reason'])->find()['name'];
                        $old_reason = $old_reason ? $old_reason : 'nothing';
                        $new_reason = $new_reason ? $new_reason : 'nothing';
                        $this->add_logs($ids,'amazon','Update reason from '.$old_reason.' to '.$new_reason);
                    }
                    if($params['followed_by'] != $oldData['followed_by']){
                        $old_follow_by = Db::table('fa_admin')->where('id',$oldData['followed_by'])->find()['nickname'];
                        $new_follow_by = Db::table('fa_admin')->where('id',$params['followed_by'])->find()['nickname'];
                        $this->add_logs($ids,'amazon','Update follow by from '.$old_follow_by.' to '.$new_follow_by);
                    }
                    if($params['reviewed'] != $oldData['reviewed']){
                        $oldData['reviewed'] = $oldData['reviewed'] ? $oldData['reviewed'] : 'nothing';
                        $params['reviewed'] = $params['reviewed'] ? $params['reviewed'] : 'nothing';
                        $this->add_logs($ids,'amazon','Update reviewed from '.$oldData['reviewed'].' to '.$params['reviewed']);
                    }
                    if($params['removed'] != $oldData['removed']){
                        $this->add_logs($ids,'amazon','Update removed from '.$oldData['removed'].' to '.$params['removed']);
                    }
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        
// halt($row);
        $logInfo = Db::table('fa_feedback_logs')->where('feedback_id',$ids)->where('type','amazon')->select();
        $this->view->assign("row", $row);
        $this->view->assign("logInfo", $logInfo);
        return $this->view->fetch();
    }
    /**
     * quick_update
     */
    public function quick_update($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
        // halt($params);
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    $oldData =  Db::table('fa_amazon_feedback')->where('id',$ids)->find();
                    $result = $row->allowField(true)->save($params);
                    //添加日志
                    if($params['follow_status'] != $oldData['follow_status']){
                        $this->add_logs($ids,'amazon','Update follow status from '.$oldData['follow_status'].' to '.$params['follow_status']);
                    }
                    if($params['reason'] != $oldData['reason']){
                        $old_reason = Db::table('fa_ebay_feedback_reason')->where('id',$oldData['reason'])->find()['name'];
                        $new_reason = Db::table('fa_ebay_feedback_reason')->where('id',$params['reason'])->find()['name'];
                        $old_reason = $old_reason ? $old_reason : 'nothing';
                        $new_reason = $new_reason ? $new_reason : 'nothing';
                        $this->add_logs($ids,'amazon','Update reason from '.$old_reason.' to '.$new_reason);
                    }
                    
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        
// halt($row);
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }
    /**
     * change_follower
    */
    public function change_follower($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
        // halt($params);
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    $oldData =  Db::table('fa_amazon_feedback')->where('id',$ids)->find();
                    $result = $row->allowField(true)->save($params);
                    //添加日志
                    if($params['followed_by'] != $oldData['followed_by']){
                        $old_follow_by = Db::table('fa_admin')->where('id',$oldData['followed_by'])->find()['nickname'];
                        $new_follow_by = Db::table('fa_admin')->where('id',$params['followed_by'])->find()['nickname'];
                        $this->add_logs($ids,'amazon','Update follow by from '.$old_follow_by.' to '.$new_follow_by);
                    }
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        
        $row['followed_name'] = Db::table('fa_admin')->where('id',$row['followed_by'])->find()['nickname'];
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }
    /**
     * review
     */
    public function request_removal($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
        // halt($params);
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    // $oldData =  Db::table('fa_amazon_feedback')->where('id',$ids)->find();
                    $result = $row->allowField(true)->save($params);
                    //添加日志
                    // if($params['reviewed'] != $oldData['reviewed']){
                    //     $oldData['reviewed'] = $oldData['reviewed'] ? $oldData['reviewed'] : 'nothing';
                    //     $params['reviewed'] = $params['reviewed'] ? $params['reviewed'] : 'nothing';
                    //     $this->add_logs($ids,'amazon','Update reviewed from '.$oldData['reviewed'].' to '.$params['reviewed']);
                    // }
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }
    /**
     * review
     */
    public function review($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
        // halt($params);
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    $oldData =  Db::table('fa_amazon_feedback')->where('id',$ids)->find();
                    $result = $row->allowField(true)->save($params);
                    //添加日志
                    if($params['reviewed'] != $oldData['reviewed']){
                        $oldData['reviewed'] = $oldData['reviewed'] ? $oldData['reviewed'] : 'nothing';
                        $params['reviewed'] = $params['reviewed'] ? $params['reviewed'] : 'nothing';
                        $this->add_logs($ids,'amazon','Update reviewed from '.$oldData['reviewed'].' to '.$params['reviewed']);
                    }
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }
    /**
     *添加日志
     */
    public function add_logs($feedback_id,$type,$logs)
    {
        $data['operater'] = Db::table('fa_admin')->where('id',$this->auth->id)->find()['nickname'];
        $data['created'] = date('Y-m-d H:i:s',time());
        $data['feedback_id'] = $feedback_id;
        $data['type'] = $type;
        $data['logs'] = $logs;
        $res = Db::table('fa_feedback_logs')->insertGetId($data);
    }
    /**
     * get report
     */
    public function get_report()
    {
        $feedback_date = $_POST['feedback_date'];
        $date  = explode(' - ', $feedback_date);
	    $count = count($date);
	    $from  = strtotime($date[0]);
	    if ($count == 1) {
		    $to = strtotime($date[0]) + 60*60*24;
	    } else {
		    $to = strtotime($date[1]);
	    }
	    $data = array();
	    //按rating分
	    $rating['new_1'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',1)->where('follow_status','new')->count();
	    $rating['pending_1'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',1)->where('follow_status','pending')->count();
	    $rating['closed_1'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',1)->where('follow_status','closed')->count();
	    $rating['expired_1'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',1)->where('follow_status','expired')->count();
	    $rating['new_2'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',2)->where('follow_status','new')->count();
	    $rating['pending_2'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',2)->where('follow_status','pending')->count();
	    $rating['closed_2'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',2)->where('follow_status','closed')->count();
	    $rating['expired_2'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',2)->where('follow_status','expired')->count();
	    $rating['new_3'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',3)->where('follow_status','new')->count();
	    $rating['pending_3'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',3)->where('follow_status','pending')->count();
	    $rating['closed_3'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',3)->where('follow_status','closed')->count();
	    $rating['expired_3'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',3)->where('follow_status','expired')->count();
	    $rating['new_4'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',4)->where('follow_status','new')->count();
	    $rating['pending_4'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',4)->where('follow_status','pending')->count();
	    $rating['closed_4'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',4)->where('follow_status','closed')->count();
	    $rating['expired_4'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',4)->where('follow_status','expired')->count();
	    $rating['new_5'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',5)->where('follow_status','new')->count();
	    $rating['pending_5'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',5)->where('follow_status','pending')->count();
	    $rating['closed_5'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',5)->where('follow_status','closed')->count();
	    $rating['expired_5'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('rating',5)->where('follow_status','expired')->count();
	    
	    //角色id为2392564224,2392564225角色id为2392564225的user
        $uids = Db::table('fa_auth_group_access')->where('group_id','in',['1','2392564224','2392564225',])->select();
        $follow_count = array();
        $follow_ids = array();
        $removed_count = array();
        for($i=0;$i<count($uids);$i++){
            $userInfo = Db::table('fa_admin')->where('userid',$uids[$i]['uid'])->find();
            $uidData['name'] = $userInfo['nickname'];
            array_push($follow_ids,$userInfo['id']);
            $uidData['new'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('followed_by',$userInfo['id'])->where('follow_status','new')->count();
            $uidData['pending'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('followed_by',$userInfo['id'])->where('follow_status','pending')->count();
            $uidData['closed'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('followed_by',$userInfo['id'])->where('follow_status','closed')->count();
            $uidData['expired'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('followed_by',$userInfo['id'])->where('follow_status','expired')->count();
            $removedData['name'] = $userInfo['nickname'];
            $removedData['qty'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('followed_by',$userInfo['id'])->where('removed','Y')->count();
            $removed_count[] = $removedData;
            $follow_count[] = $uidData;
        }
        //未分配的统计
        $unfollow['name'] = '未分配';
        $unfollow['new'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('followed_by','not in',$follow_ids)->where('follow_status','new')->count();
        $unfollow['pending'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('followed_by','not in',$follow_ids)->where('follow_status','pending')->count();
        $unfollow['closed'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('followed_by','not in',$follow_ids)->where('follow_status','closed')->count();
        $unfollow['expired'] = Db::table('fa_amazon_feedback')->whereTime('feedback_date', 'BETWEEN', [$from,$to])->where('followed_by','not in',$follow_ids)->where('follow_status','expired')->count();
        
        array_push($follow_count,$unfollow);
        
        $data['rating'] = $rating;
        $data['follow_count'] = $follow_count;
        $data['removed_count'] = $removed_count;
        return $data;
    }
    /**
     * 导入
     */
    public function import()
    {
        $file = $this->request->request('file');
        if (!$file) {
            $this->error(__('Parameter %s can not be empty', 'file'));
        }
        $filePath = ROOT_PATH . DS . 'public' . DS . $file;
        if (!is_file($filePath)) {
            $this->error(__('No results were found'));
        }
        //操作者信息
        $auth_name = Db::table('fa_admin')->where('id',$this->auth->id)->find();
        //实例化reader
        $ext = pathinfo($filePath, PATHINFO_EXTENSION);
        if (!in_array($ext, ['csv', 'xls', 'xlsx'])) {
            $this->error(__('Unknown data format'));
        }
        
        if ($ext === 'csv') {
            $file = fopen($filePath, 'r');
            $filePath = tempnam(sys_get_temp_dir(), 'import_csv');
            $fp = fopen($filePath, "w");
            $n = 0;
            while ($line = fgets($file)) {
                $line = rtrim($line, "\n\r\0");
                $encoding = mb_detect_encoding($line, ['utf-8', 'gbk', 'latin1', 'big5']);
                if ($encoding != 'utf-8') {
                    $line = mb_convert_encoding($line, 'utf-8', $encoding);
                }
                if ($n == 0 || preg_match('/^".*"$/', $line)) {
                    fwrite($fp, $line . "\n");
                } else {
                    fwrite($fp, '"' . str_replace(['"', ','], ['""', '","'], $line) . "\"\n");
                }
                $n++;
            }
            fclose($file) || fclose($fp);

            $reader = new Csv();
        } elseif ($ext === 'xls') {
            $reader = new Xls();
        } else {
            $reader = new Xlsx();
        }

        //导入文件首行类型,默认是注释,如果需要使用字段名称请使用name
        $importHeadType = isset($this->importHeadType) ? $this->importHeadType : 'comment';

        $table = $this->model->getQuery()->getTable();
        $database = \think\Config::get('database.database');
        $fieldArr = [];
        $list = db()->query("SELECT COLUMN_NAME,COLUMN_COMMENT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ? AND TABLE_SCHEMA = ?", [$table, $database]);
        foreach ($list as $k => $v) {
            if ($importHeadType == 'comment') {
                $fieldArr[$v['COLUMN_COMMENT']] = $v['COLUMN_NAME'];
            } else {
                $fieldArr[$v['COLUMN_NAME']] = $v['COLUMN_NAME'];
            }
        }

        //加载文件
        $insert = [];
        try {
            if (!$PHPExcel = $reader->load($filePath)) {
                $this->error(__('Unknown data format'));
            }
            $currentSheet = $PHPExcel->getSheet(0);  //读取文件中的第一个工作表
            $allColumn = $currentSheet->getHighestDataColumn(); //取得最大的列号

            $allRow = $currentSheet->getHighestRow(); //取得一共有多少行

            $maxColumnNumber = Coordinate::columnIndexFromString($allColumn);
            $fields = [];
            for ($currentRow = 1; $currentRow <= 1; $currentRow++) {
                for ($currentColumn = 1; $currentColumn <= $maxColumnNumber; $currentColumn++) {
                    $val = $currentSheet->getCellByColumnAndRow($currentColumn, $currentRow)->getValue();
                    $fields[] = $val;
                }
            }

            for ($currentRow = 2; $currentRow <= $allRow; $currentRow++) {
                $values = [];
                for ($currentColumn = 1; $currentColumn <= $maxColumnNumber; $currentColumn++) {
                    $val = $currentSheet->getCellByColumnAndRow($currentColumn, $currentRow)->getValue();
                    $values[] = is_null($val) ? '' : $val;
                }
                $row = [];
                $temp = array_combine($fields, $values);
                
// halt($temp);
                foreach ($temp as $k => $v) {
                    if (isset($fieldArr[$k]) && $k !== '') {
                        if($k == 'Feedback Date'){
                            $v =  $v != '' ? gmdate('Y-m-d H:i:s',(trim($v)-25569)*3600*24) : '';
                        }
                        if($k == 'Followed by'){
                            $v =  $v != '' ? Db::table('fa_admin')->where('nickname',$v)->find()['id'] : $this->auth->id;
                        } 
                        $row[$fieldArr[$k]] = $v;
                    }
                }
                $row['added_on'] = date('Y-m-d H:i:s',time());
                $row['added_by'] = $auth_name['nickname'];
    // halt($row);
                if ($row) {
                    if(!Db::table('fa_amazon_feedback')->where('order_id',$row['order_id'])->find()){
                        $insert[] = $row;
                    }
                }
            }
        } catch (Exception $exception) {
            $this->error($exception->getMessage());
        }
        if (!$insert) {
            $this->error(__('No rows were updated'));
        }

        try {
            //是否包含admin_id字段
            $has_admin_id = false;
            foreach ($fieldArr as $name => $key) {
                if ($key == 'admin_id') {
                    $has_admin_id = true;
                    break;
                }
            }
            if ($has_admin_id) {
                $auth = Auth::instance();
                foreach ($insert as &$val) {
                    if (!isset($val['admin_id']) || empty($val['admin_id'])) {
                        $val['admin_id'] = $auth->isLogin() ? $auth->id : 0;
                    }
                }
            }
            $this->model->saveAll($insert);
        } catch (PDOException $exception) {
            $msg = $exception->getMessage();
            if (preg_match("/.+Integrity constraint violation: 1062 Duplicate entry '(.+)' for key '(.+)'/is", $msg, $matches)) {
                $msg = "导入失败，包含【{$matches[1]}】的记录已存在";
            };
            $this->error($msg);
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }

        $this->success();
    }

}
