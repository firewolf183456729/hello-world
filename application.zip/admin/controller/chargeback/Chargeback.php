<?php

namespace app\admin\controller\chargeback;

use app\common\controller\Backend;
use think\Db;
use fast\Tree;

/**
 * Chargeback
 *
 * @icon fa fa-circle-o
 */
class Chargeback extends Backend
{
    
    /**
     * Chargeback模型对象
     * @var \app\admin\model\chargeback\Chargeback
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\chargeback\Chargeback;
        $this->view->assign("contactedUsList", $this->model->getContactedUsList());
        $this->view->assign("repliedCustomerList", $this->model->getRepliedCustomerList());
        $this->view->assign("shippedPartsList", $this->model->getShippedPartsList());
        $this->view->assign("orderReturnedList", $this->model->getOrderReturnedList());
        $this->view->assign("isRefundedList", $this->model->getIsRefundedList());
        $caseStatusLists=$this->model->caseStatusList();
        //列表头部的TAB选项卡
        $caseStatusList = Db::table('fa_chargeback_case_status')->select();
        $chargebackStatusList = Db::table('fa_chargeback_status')->select();
        $this->view->assign("caseStatusList", $caseStatusList);
        $this->assignconfig("caseStatusList", $caseStatusLists);
        // halt($caseStatusLists);
        $this->view->assign("chargebackStatusList", $chargebackStatusList);
        $case_count = [];
        $chargeback_count = [];
        for($i=0;$i<count($caseStatusList);$i++){
            $case_count[$caseStatusList[$i]['id']] =  Db::table('fa_chargeback')->where('case_status','=',$caseStatusList[$i]['id'])->count();
        }
        for($i=0;$i<count($chargebackStatusList);$i++){
            $chargeback_count[$chargebackStatusList[$i]['id']] =  Db::table('fa_chargeback')->where('chargeback_status','=',$chargebackStatusList[$i]['id'])->count();
        }
        $review_count = Db::table('fa_chargeback')->where('review_status','=',4)->where('case_status','in','3,4,5')->count();
        $this->view->assign("review_count", $review_count);
        $this->view->assign("case_count", $case_count);
        $this->view->assign("chargeback_count", $chargeback_count);
        $this->view->assign("admin_id", $this->auth->userid);
        $this->assignconfig("admin", ['id' => $this->auth->userid]);
        //判断是否为agent
        $is_agent =  Db::table('fa_auth_group_access')->where('uid','=',$this->auth->userid)->where('group_id','=','2392564218')->find();
        if($is_agent){
            $this->assignconfig("is_agent", 1);
        }else{
            $this->assignconfig("is_agent", 0);
        }
        
    }

    public function import()
    {
        parent::import();
    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
    

    /**
     * 查看
     */
    public function index()
    {
        //当前是否为关联查询
        $this->relationSearch = false;
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            // //获取传递的参数
            // $cusFilter = $this->request->get("cusfilter", '');
            // $cusFilter=(array)json_decode($cusFilter,true);
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            //如果参数不是空的 增加query的条件
            // if(isset($cusFilter['statusfilter'])) {
            //     $this->model->where('case_status', $cusFilter['caseStatusList']);
            // }
            $params = $this->request->get('');
            // halt($params);
            // halt(json_decode($params['filter'],':'));
            if(isset(json_decode($params['filter'],':')['case_status']) && json_decode($params['filter'],':')['case_status'] == 6){
                $list = $this->model
                    // ->where($where)
                    ->where('review_status',4)
                    ->where('case_status','in','3,4,5')
                    ->order($sort, $order)
                    ->paginate($limit);
                
            }else{
                $list = $this->model
                    
                    ->where($where)
                    ->order($sort, $order)
                    ->paginate($limit);
            }
            
            

            foreach ($list as $row) {
                $row['case_status'] = Db::table('fa_chargeback_case_status')->where('id','=',$row['case_status'])->find()['name'];
                $row['chargeback_status'] = Db::table('fa_chargeback_status')->where('id','=',$row['chargeback_status'])->find()['name'];
                $row['payment_method'] = Db::table('fa_chargeback_payment_method')->where('id','=',$row['payment_method'])->find()['name'];
                $row['store'] = Db::table('fa_erp_shops')->where('id','=',$row['store'])->find()['name'];
                $row['agent'] = Db::table('fa_admin')->where('id','=',$row['agent'])->find()['nickname'];
                $row['reviewed_by'] = Db::table('fa_admin')->where('id','=',$row['reviewed_by'])->find()['nickname'];
                $row['review_status'] = Db::table('fa_chargeback_review_status')->where('id','=',$row['review_status'])->find()['name'];
                $row['case_result'] = Db::table('fa_chargeback_case_result')->where('id','=',$row['case_result'])->find()['name'];
                $liability = Db::table('fa_chargeback_liability')->where('id','in',$row['liability'])->select();
                $row['liability'] = '';
                for($i=0;$i<count($liability);$i++){
                    $row['liability'] .= $liability[$i]['name'].',';
                }
                $row['liability'] = trim($row['liability'],',');
                $row->visible(['id','case_status','agent','case_id','chargeback_status','transaction_date','chargeback_amount','case_filed_on','reason','must_respond_by','customer_comment','order_num','store','order_date','status','order_amount','carrier','tracking_num','order_refunded','payment_method','customer_name','email','products','response','review_date','reviewed_by','review_status','case_result','liability','contacted_us','replied_customer','shipped_parts','order_returned','is_refunded','solution','rating','suggestions','remark']);
                
            }

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }
    /**
     * 添加
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);

                if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
                    $params[$this->dataLimitField] = $this->auth->id;
                }
                $params['create_time'] = date('Y-m-d H:i:s',time());
                $params['update_time'] = date('Y-m-d H:i:s',time());
    // halt($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                        $this->model->validateFailException(true)->validate($validate);
                    }
                    $result = $this->model->allowField(true)->save($params);
        // halt($result);
                    //增加日志
                    $case_status = Db::table('fa_chargeback_case_status')->where('id','=',$params['case_status'])->find()['name'];
                    $chargeback_res = Db::table('fa_chargeback')->order('id', 'desc')->select();
                    $this->chargeback_agent_logs($chargeback_res[0]['id'],'created the case','Case Status:'.$case_status);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were inserted'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        return $this->view->fetch();
    }

    /**
     * 编辑
     */
    public function edit($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                $params['update_time'] = date('Y-m-d H:i:s',time());
    // halt($row['case_status'].'--'.$params['case_status']);
                
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    //查询原数据以便增加日志
                    $old_info = Db::table('fa_chargeback')->where('id','=',$ids)->find();
                    $result = $row->allowField(true)->save($params);
                    //增加日志
                    if($old_info['case_status'] != $params['case_status']){
                        $case_status_old =  Db::table('fa_chargeback_case_status')->where('id','=',$old_info['case_status'])->find()['name'];
                        $case_status_new =  Db::table('fa_chargeback_case_status')->where('id','=',$params['case_status'])->find()['name'];
                        $this->chargeback_agent_logs($ids,'Update Case Status','Update Case Status From '.$case_status_old.' to '.$case_status_new);
                    }
                    if($old_info['chargeback_status'] != $params['chargeback_status']){
                        $chargeback_status_old =  Db::table('fa_chargeback_status')->where('id','=',$old_info['chargeback_status'])->find()['name'];
                        $chargeback_status_new =  Db::table('fa_chargeback_status')->where('id','=',$params['chargeback_status'])->find()['name'];
                        $this->chargeback_agent_logs($ids,'Update Chargeback Status','Update Chargeback Status From '.$chargeback_status_old.' to '.$chargeback_status_new);
                    }
                    if($old_info['agent'] != $params['agent']){
                        $agent_old =  Db::table('fa_admin')->where('id','=',$old_info['agent'])->find()['nickname'];
                        $agent_new =  Db::table('fa_admin')->where('id','=',$params['agent'])->find()['nickname'];
                        $this->chargeback_agent_logs($ids,'Update Agent','Update Agent From '.$agent_old.' to '.$agent_new);
                    }
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }
    /**
     * 操作日志
     */
    public function chargeback_agent_logs($chargeback_id,$action='',$status='')
    {
        $date = date('Y-m-d H:i:s',time());
        $agent = Db::table('fa_admin')->where('id',$this->auth->id)->value('nickname');
        $data['date'] = $date;
        $data['agent'] = $agent;
        $data['status'] = $status;
        $data['action'] = $action;
        $data['chargeback_id'] = $chargeback_id;
        $res = Db::table('fa_chargeback_agent_logs')->insertGetId($data);
    }
    /**
     * 产品详情
     */
    public function product_details()
    {
        $id = $_POST['id'];
        $product_info = Db::table('fa_product')->where('id',$id)->find();
        
        if($product_info){
            $product_info['category'] = Db::table('fa_product_category')->where('id',$product_info['category'])->value('chinese_name');
            $product_info['brand'] = Db::table('fa_product_brand')->where('id',$product_info['brand'])->value('name');
            $data['code'] = 1;
            $data['product'] = $product_info;
        }else{
            $data['code'] = 0;
        }
        return $data;
        
    }
    /**
     * View详情
     */
    public function view($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        $row['case_status'] = Db::table('fa_chargeback_case_status')->where('id','=',$row['case_status'])->find()['name'];
        $row['chargeback_status'] = Db::table('fa_chargeback_status')->where('id','=',$row['chargeback_status'])->find()['name'];
        $row['agent'] = Db::table('fa_admin')->where('id','=',$row['agent'])->find()['nickname'];
        $row['store'] = Db::table('fa_erp_shops')->where('id','=',$row['store'])->find()['name'];
        $row['payment_method'] = Db::table('fa_chargeback_payment_method')->where('id','=',$row['payment_method'])->find()['name'];
        $row['products'] = Db::table('fa_product')->where('id','in',$row['products'])->select();
        
        $row['reviewed_by'] = Db::table('fa_admin')->where('id','=',$row['reviewed_by'])->find()['nickname'];
        $row['case_result'] = Db::table('fa_chargeback_case_result')->where('id','=',$row['case_result'])->find()['name'];
        $liability = Db::table('fa_chargeback_liability')->where('id','in',$row['liability'])->select();
        $liabilitys = '';
        for($i=0;$i<count($liability);$i++){
            $liabilitys .= $liability[$i]['name'] .',';
        }
        $row['liability'] = trim($liabilitys,',');
// halt($row['case_status']);
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }
    /**
     * Update status
     */
    public function update_status($ids = null)
    {
        $res = Db::table('fa_chargeback')->where('id',$ids)->update(['case_status'=>2]);
        if($res){
            $data['code'] = 1;
            $data['msg']  = 'Success!';
            $this->chargeback_agent_logs($ids,'Update Status','Case Status:Pending');
        }else{
            $data['code'] = 0;
            $data['msg']  = 'Failed!';
        }
        return $data;
    }
    /**
     * review
     */
    public function review($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                $params['update_time'] = date('Y-m-d H:i:s',time());
                $params['reviewed_by'] = $this->auth->id;
    // halt($params);
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    //查询原数据以便增加日志
                    $old_info = Db::table('fa_chargeback')->where('id','=',$ids)->find();
                    $result = $row->allowField(true)->save($params);
                    //增加日志
                    if($old_info['review_status'] != $params['review_status']){
                        $review_status_old =  Db::table('fa_chargeback_review_status')->where('id','=',$old_info['review_status'])->find()['name'];
                        $review_status_new =  Db::table('fa_chargeback_review_status')->where('id','=',$params['review_status'])->find()['name'];
                        $this->chargeback_agent_logs($ids,'Update Review Status','Update Review Status From '.$review_status_old.' to '.$review_status_new);
                    }
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }
    /**
     * 获取产品信息
     */
    public function get_products_info()
    {
        $product_ids = $_POST['product_ids'];
        $product_infos = Db::table('fa_product')->where('id','in',$product_ids)->select();
        if($product_infos){
            $data['code'] = 1;
            $data['products'] = $product_infos;
        }else{
            $data['code'] = 0;
            $data['products'] = [];
        }
        return $data;
    }
    /**
     * 获取日志信息
     */
    public function get_logs(){
        $chargeback_id = $_POST['chargeback_id'];
        $chargeback_infos = Db::table('fa_chargeback_agent_logs')->where('chargeback_id','=',$chargeback_id)->select();
        if($chargeback_infos){
            $data['code'] = 1;
            $data['logs'] = $chargeback_infos;
        }else{
            $data['code'] = 0;
            $data['logs'] = [];
        }
        return $data;
    }


}
