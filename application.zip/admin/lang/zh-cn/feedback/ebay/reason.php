<?php

return [
    'Id'       => 'ID',
    'Name'     => 'Reason',
    'Added_on' => 'Added on',
    'Operate'     => 'Operate'
];
