<?php

return [
    'Id'                => 'ID',
    'Feedback_date'     => 'Feedback Date',
    'Store_id'          => 'Store ID',
    'Order_id'          => 'Order ID',
    'Rating'            => 'Rating',
    'Sku'               => 'SKU',
    'Asin'              => 'ASIN',
    'Comments'          => 'comments',
    'Followed_by'       => 'Followed by',
    'Follow_status'     => 'Follow Satus',
    'Added_on'          => 'Added on',
    'Added_by'          => 'Added by',
    'Ticket_id'         => 'Ticket ID',
    'Ticket_reappealed' => 'Ticket Reappealed',
    'Reason'            => 'Reason',
    'Removed'           => 'Removed',
    'Reviewed'          => 'Reviewed',
    'Screenshot'        => 'Screenshot',
    'Remarks'           => 'Remarks'
];
