<?php

return [
    'Id'          => 'ID',
    'Name'        => 'Payment Method',
    'Create_time' => '创建时间',
    'Update_time' => '修改时间'
];
