<?php

return [
    'Id'          => 'ID',
    'Name'        => 'Case Result',
    'Create_time' => 'Create Time',
    'Update_time' => 'Update Time'
];
