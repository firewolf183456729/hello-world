<?php

return [
    'Id'          => 'ID',
    'Name'        => 'Review Status',
    'Create_time' => '创建时间',
    'Update_time' => '修改时间'
];
