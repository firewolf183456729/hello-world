<?php

return [
    'Id'          => 'ID',
    'Name'        => 'Liability',
    'Create_time' => 'Create Time',
    'Update_time' => 'Update Time'
];
