<?php

return [
    'Cn_name'    => '中文名称',
    'En_name'    => '英文名称',
    'Local_name' => '本地语名称',
    'Two_code'   => '国家或地区二字代码',
    'Three_code' => '国家或地区三字码',
    'Currency'   => '货币',
    'Status'     => '状态'
];
