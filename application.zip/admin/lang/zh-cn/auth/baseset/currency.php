<?php

return [
    'Name'          => '货币名称',
    'En_name'       => '英文名称',
    'Identifier'    => '标示符左',
    'Float_num'     => '小数位数',
    'Exchange_rate' => '时实汇率',
    'Code'          => '货币code'
];
