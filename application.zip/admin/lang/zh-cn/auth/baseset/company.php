<?php

return [
    'Company_name'      => '公司名称',
    'Company_shortcode' => '简称',
    'Status'            => '状态'
];
