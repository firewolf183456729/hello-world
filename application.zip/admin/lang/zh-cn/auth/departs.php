<?php

return [
    'Pid'       => '上级id',
    'Dept_id'   => '部门id',
    'Dept_name' => '部门名称',
    'Created'   => '创建时间',
    'Updated'   => '修改时间'
];
