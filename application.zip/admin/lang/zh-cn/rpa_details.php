<?php

return [
    'Run_id'         => '运行ID',
    'Url'            => '报表下载url',
    'Run_name'       => '报表名称',
    'Rpa_name'       => 'RPA名称',
    'Store_name'     => '店铺名称',
    'Site_name'      => '站点名称',
    'Site_name_en'   => '站点名称（英文）',
    'Platform_type'  => '平台类型 0:Amazon 1:速卖通 2:Lazada 3:Ebay 4:paypal 5:沃尔玛',
    'Start_time'     => '报表开始时间',
    'End_time'       => '报表结束时间',
    'Finish_time'    => '上传服务器时间',
    'Seller_id'      => '卖家ID',
    'Marketplace_id' => '站点ID'
];
