<?php

return [
    'Id'          => 'ID',
    'Code'        => '代码',
    'Name'        => '名称',
    'Name_en'     => '英文名称',
    'Short_name'  => '简称',
    'Description' => '描述'
];
