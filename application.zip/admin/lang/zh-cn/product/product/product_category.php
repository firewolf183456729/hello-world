<?php

return [
    'Pid'            => '上级',
    'Chinese_name'   => '中文名',
    'English_name'   => '英文名',
    'Custom_num'     => '海关编号',
    'Level'          => '等级',
    'Reference_code' => '参考码',
    'Organization'   => '组织机构',
    'Status'         => '状态'
];
