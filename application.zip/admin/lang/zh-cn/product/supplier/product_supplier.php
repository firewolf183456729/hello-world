<?php

return [
    'Code'                  => '供应商代码',
    'Chinese_name'          => '中文名称',
    'Grade'                 => '等级',
    'English_name'          => '英文名称',
    'Cooperation_type'      => '合作类型',
    'Product_category_id'   => '主营品类',
    'Type'                  => '类型',
    'Buyer_id'              => '采购员',
    'Merchandiser_id'       => '默认跟单员',
    'Supplier_developer_id' => '供应商开发人',
    'Organization'          => '组织机构',
    'Supplier_tax_number'   => '供应商税号',
    'Settlement_methods'    => '结算方式',
    'Payment_cycle_type'    => '支付周期类型',
    'Payment_method'        => '默认支付方式',
    'Undertaker'            => '运输承担方',
    'Shipping_type'         => '默认运输方式',
    'Carrier'               => '默认承运商',
    'Supplier_country'      => '供应商国家',
    'Supplier_state'        => '供应商省',
    'Supplier_city'         => '供应商城市',
    'Supplier_address'      => '供应商地址',
    'Status'                => '状态',
    'Add_time'              => '创建时间',
    'Update_time'           => '修改时间'
];
