<?php

return [
    'Id'       => 'ID',
    'Color'    => '颜色',
    'Color_en' => '颜色(英文)',
    'Code'     => '代码',
    'Sort'     => '排序'
];
