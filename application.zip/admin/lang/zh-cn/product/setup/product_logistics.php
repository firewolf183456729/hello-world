<?php

return [
    'Id'          => 'ID',
    'Name'        => '属性名称',
    'Description' => '属性描述',
    'Enable'      => '是否启用'
];
