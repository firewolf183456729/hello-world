<?php

return [
    'Id'            => 'ID',
    'Name'          => '品牌名称',
    'Image'         => 'LOGO',
    'Description'   => '品牌描述',
    'Url'           => '品牌网址',
    'Warning_title' => '警告标题',
    'Warning_text'  => '警告内容',
    'Sort'          => '排序',
    'Is_enable'     => '是否启用'
];
