<?php

return [
    'Id'      => 'ID',
    'Name'    => '自定义分类名称',
    'Created' => '创建时间',
    'Updated' => '修改时间'
];
