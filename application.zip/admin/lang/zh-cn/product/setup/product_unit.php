<?php

return [
    'Id'           => 'ID',
    'Unit_name'    => '单位名称',
    'Unit_name_en' => '单位名称(英文)',
    'Code'         => '代码',
    'Sort'         => '排序'
];
