<?php

return [
    'Id'                => 'ID',
    'Code'              => '代码',
    'Name'              => '名称',
    'Name_en'           => '英文名称',
    'Purchase_proposal' => '是否生成采购建议',
    'Census'            => '是否统计到产品动销分析',
    'Status'            => '状态',
    'Default_status'    => '默认销售状态',
    'Created'           => '创建时间',
    'Updated'           => '修改时间'
];
