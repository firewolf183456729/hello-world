<?php

return [
    'Id'           => 'ID',
    'Size_name'    => '尺寸名称',
    'Size_name_en' => '尺寸名称(英文)',
    'Code'         => '代码',
    'Sort'         => '排序'
];
