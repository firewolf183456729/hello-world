<?php

return [
    'Id'      => 'ID',
    'Code'    => '代码',
    'Name'    => '名称',
    'Name_en' => '英文名称',
    'Grade'   => '等级',
    'Status'  => '状态',
    'Created' => '创建时间',
    'Updated' => '修改时间'
];
