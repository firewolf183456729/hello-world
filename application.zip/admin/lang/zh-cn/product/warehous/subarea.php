<?php

return [
    'Warehouse_code' => '仓库代码',
    'Partition_name' => '分区名称',
    'English_name'   => '英文名',
    'Partition_code' => '分区代码',
    'Partition_type' => '分区类型',
    'Inventory_type' => '存货类型',
    'Priority'       => '优先级',
    'Status'         => '状态',
    'Category'       => '品类',
    'Create_time'    => '添加时间',
    'Update_time'    => '更新时间'
];
