<?php

return [
    'Id'             => 'ID',
    'Warehouse_code' => '仓库代码',
    'Partition_code' => '分区代码',
    'Location'       => '库位',
    'Description'    => '描述',
    'Status'         => '状态',
    'Passageway_id'  => '通道ID',
    'Picking_sort'   => '拣货顺序',
    'Temporary'      => '标记到临时库位',
    'Create_time'    => '添加时间',
    'Update_time'    => '修改时间'
];
