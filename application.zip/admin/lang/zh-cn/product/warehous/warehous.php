<?php

return [
    'Warehouse_code' => '仓库代码',
    'Warehouse_name' => '仓库名称',
    'Sort'           => '排序',
    'Type'           => '类型',
    'Operation_mode' => '运营方式',
    'Country'        => '国家',
    'States'         => '州/省',
    'City'           => '城市',
    'Postcode'       => '邮编',
    'House_number'   => '门牌号',
    'Address1'       => '地址',
    'Address2'       => '地址二',
    'Contacts'       => '联系人',
    'Tel'            => '电话',
    'Company'        => '公司',
    'Status'         => '状态'
];
