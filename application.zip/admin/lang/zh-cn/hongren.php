<?php

return [
    'Name'                 => '红人姓名',
    'Grade'                => '评级',
    'Cooperation_num'      => '合作次数',
    'Release_links'        => '已发布链接',
    'Cooperation_progress' => '合作进度',
    'Country'              => '国家',
    'Email'                => '邮箱',
    'Gender'               => '性别',
    'Age'                  => '年龄',
    'Main_category'        => '主要类目',
    'Money'                => '报价',
    'Receiving'            => '收件人',
    'Receive_address'      => '收件地址',
    'Phone'                => '手机号',
    'Contact'              => '联系人',
    'Remark'               => '备注',
    'Createtime'           => '创建时间',
    'Updatetime'           => '修改时间'
];
