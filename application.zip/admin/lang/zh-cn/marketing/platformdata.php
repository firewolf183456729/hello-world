<?php

return [
    'Platform'       => '平台名称',
    'Item_name'      => '项目名称',
    'Ft_date'        => '发帖日期',
    'Record_date'    => '数据截止日期',
    'Content'        => '主要内容',
    'Link'           => '链接',
    'View_num'       => '观看量',
    'Thumbs_num'     => '点赞数',
    'Step_num'       => '踩',
    'Comment_num'    => '评论数',
    'Relay_num'      => '转发数',
    'Collect_num'    => '收藏数',
    'Link_click_num' => '链接点击数',
    'Spend'          => '花费（$）',
    'Remark'         => '备注',
    'Created'        => '创建时间',
    'Updated'        => '修改时间',
    'Hongren'        => '红人',
    'Create_by'      => '创建人'
];
