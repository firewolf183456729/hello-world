<?php

return [
    'Name'    => '平台名称',
    'Created' => '创建时间',
    'Updated' => '修改时间'
];
