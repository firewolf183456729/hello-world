<?php

return [
    'Rpa_id'   => 'RPA ID',
    'Rpa_name' => 'RPA名称',
    'Platform' => '平台',
    'Rpa_tag'  => 'RPA标签',
    'Created'  => '创建时间',
    'Updated'  => '更新时间'
];
