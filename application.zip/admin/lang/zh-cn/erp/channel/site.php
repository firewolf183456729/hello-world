<?php

return [
    'Id'          => 'ID',
    'Name'        => '站点名',
    'Create_time' => '创建时间',
    'Update_time' => '修改时间'
];
