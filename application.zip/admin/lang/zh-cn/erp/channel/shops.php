<?php

return [
    'Id'                   => 'ID',
    'Name'                 => '店铺名称',
    'Erp_num'              => '店铺erp编号',
    'Belong_to'            => '归属',
    'Status'               => '店铺状态',
    'Manager'              => '账号经理',
    'Channel_type'         => '渠道类型',
    'Platform'             => '平台',
    'Site'                 => '站点',
    'Currency'             => '币种',
    'Email'                => '主账号邮箱',
    'Username'             => '主账号用户名',
    'Phone'                => '客服电话',
    'Company'              => '关联公司',
    'Address'              => '关联公司地址',
    'Collection_card'      => '关联收款卡',
    'Credit_card'          => '关联信用卡',
    'Assignment_agreement' => '是否与收入归属公司签有店铺转让协议',
    'Deposit'              => '是否有押金',
    'Bind_name'            => '绑定账户名',
    'Bind_card'            => '绑定账户账号',
    'Creator'              => '创建人',
    'Create_time'          => '创建时间',
    'Update_time'          => '修改时间'
];
