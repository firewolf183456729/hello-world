<?php

return [
    'Id'          => 'ID',
    'Name'        => '平台名称',
    'Status'      => '状态',
    'Create_time' => '创建时间',
    'Update_time' => '更新时间'
];
