<?php

namespace app\admin\model\erp\channel;

use think\Model;


class Shops extends Model
{

    

    

    // 表名
    protected $name = 'erp_shops';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'belong_to_text',
        'status_text',
        'channel_type_text',
        'assignment_agreement_text',
        'deposit_text'
    ];
    

    
    public function getBelongToList()
    {
        return ['择尚' => __('择尚'), '合作方' => __('合作方')];
    }

    public function getStatusList()
    {
        return ['正常' => __('正常'), '关闭' => __('关闭')];
    }

    public function getChannelTypeList()
    {
        return ['多渠道' => __('多渠道'), '独立站' => __('独立站')];
    }

    public function getAssignmentAgreementList()
    {
        return ['是' => __('是'), '否' => __('否')];
    }

    public function getDepositList()
    {
        return ['是' => __('是'), '否' => __('否')];
    }


    public function getBelongToTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['belong_to']) ? $data['belong_to'] : '');
        $list = $this->getBelongToList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getChannelTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['channel_type']) ? $data['channel_type'] : '');
        $list = $this->getChannelTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getAssignmentAgreementTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['assignment_agreement']) ? $data['assignment_agreement'] : '');
        $list = $this->getAssignmentAgreementList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getDepositTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['deposit']) ? $data['deposit'] : '');
        $list = $this->getDepositList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
