<?php

namespace app\admin\model\feedback\ebay;

use think\Model;


class Feedback extends Model
{

    

    

    // 表名
    protected $name = 'ebay_feedback';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'ticket_reappealed_text',
        'removed_text',
        'reviewed_text'
    ];
    

    
    public function getTicketReappealedList()
    {
        return ['' => __(''), 'Y' => __('Y'), 'N' => __('N')];
    }

    public function getRemovedList()
    {
        return ['' => __(''), 'Y' => __('Y'), 'N' => __('N')];
    }

    public function getReviewedList()
    {
        return ['' => __(''), '1' => __('Reviewed 1'), '2' => __('Reviewed 2'), '3' => __('Reviewed 3'), '4' => __('Reviewed 4'), '5' => __('Reviewed 5')];
    }


    public function getTicketReappealedTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['ticket_reappealed']) ? $data['ticket_reappealed'] : '');
        $list = $this->getTicketReappealedList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getRemovedTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['removed']) ? $data['removed'] : '');
        $list = $this->getRemovedList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getReviewedTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['reviewed']) ? $data['reviewed'] : '');
        $list = $this->getReviewedList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
