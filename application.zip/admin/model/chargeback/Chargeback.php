<?php

namespace app\admin\model\chargeback;

use think\Model;


class Chargeback extends Model
{

    

    

    // 表名
    protected $name = 'chargeback';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'contacted_us_text',
        'replied_customer_text',
        'shipped_parts_text',
        'order_returned_text',
        'is_refunded_text'
    ];
    

    
    public function getContactedUsList()
    {
        return ['No' => __('No'), 'Yes' => __('Yes')];
    }

    public function getRepliedCustomerList()
    {
        return ['No' => __('No'), 'Yes' => __('Yes')];
    }

    public function getShippedPartsList()
    {
        return ['No' => __('No'), 'Yes' => __('Yes')];
    }

    public function getOrderReturnedList()
    {
        return ['No' => __('No'), 'Yes' => __('Yes')];
    }

    public function getIsRefundedList()
    {
        return ['No' => __('No'), 'Yes' => __('Yes')];
    }


    public function getContactedUsTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['contacted_us']) ? $data['contacted_us'] : '');
        $list = $this->getContactedUsList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getRepliedCustomerTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['replied_customer']) ? $data['replied_customer'] : '');
        $list = $this->getRepliedCustomerList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getShippedPartsTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['shipped_parts']) ? $data['shipped_parts'] : '');
        $list = $this->getShippedPartsList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getOrderReturnedTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['order_returned']) ? $data['order_returned'] : '');
        $list = $this->getOrderReturnedList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getIsRefundedTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_refunded']) ? $data['is_refunded'] : '');
        $list = $this->getIsRefundedList();
        return isset($list[$value]) ? $list[$value] : '';
    }
    public function caseStatusList(){
       return array("1"=>"Action Required","2"=>"Pending","3"=>"Win","4"=>"Lost","5"=>"No contest");
   }



}
