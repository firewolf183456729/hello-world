<?php

namespace app\admin\model\product\supplier;

use think\Model;


class ProductSupplier extends Model
{

    

    

    // 表名
    protected $name = 'product_supplier';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'grade_text',
        'cooperation_type_text',
        'type_text',
        'settlement_methods_text',
        'payment_cycle_type_text',
        'payment_method_text',
        'undertaker_text',
        'shipping_type_text',
        'status_text'
    ];
    

    
    public function getGradeList()
    {
        return ['A' => __('A'), 'B' => __('B'), 'C' => __('C'), 'D' => __('D')];
    }

    public function getCooperationTypeList()
    {
        return ['正常' => __('正常'), '临时' => __('临时'), '备用' => __('备用')];
    }

    public function getTypeList()
    {
        return ['零售' => __('零售'), '批发' => __('批发'), '生产商' => __('生产商'), '通用虚拟' => __('通用虚拟'), '线上' => __('线上'), '市场	' => __('市场	')];
    }

    public function getSettlementMethodsList()
    {
        return ['货到付款' => __('货到付款'), '款到发货' => __('款到发货'), '账期' => __('账期')];
    }

    public function getPaymentCycleTypeList()
    {
        return ['月结' => __('月结'), '隔月结' => __('隔月结'), '日结' => __('日结'), '周结' => __('周结'), '半月结	' => __('半月结	')];
    }

    public function getPaymentMethodList()
    {
        return ['现金' => __('现金'), '在线' => __('在线'), '银行卡	' => __('银行卡	')];
    }

    public function getUndertakerList()
    {
        return ['供应商' => __('供应商'), '采购方	' => __('采购方	')];
    }

    public function getShippingTypeList()
    {
        return ['自提' => __('自提'), '快递' => __('快递'), '物流' => __('物流'), '送货	' => __('送货	')];
    }

    public function getStatusList()
    {
        return ['正式供应商' => __('正式供应商')];
    }


    public function getGradeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['grade']) ? $data['grade'] : '');
        $list = $this->getGradeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getCooperationTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['cooperation_type']) ? $data['cooperation_type'] : '');
        $list = $this->getCooperationTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['type']) ? $data['type'] : '');
        $list = $this->getTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getSettlementMethodsTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['settlement_methods']) ? $data['settlement_methods'] : '');
        $list = $this->getSettlementMethodsList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPaymentCycleTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['payment_cycle_type']) ? $data['payment_cycle_type'] : '');
        $list = $this->getPaymentCycleTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPaymentMethodTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['payment_method']) ? $data['payment_method'] : '');
        $list = $this->getPaymentMethodList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getUndertakerTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['undertaker']) ? $data['undertaker'] : '');
        $list = $this->getUndertakerList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getShippingTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['shipping_type']) ? $data['shipping_type'] : '');
        $list = $this->getShippingTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
