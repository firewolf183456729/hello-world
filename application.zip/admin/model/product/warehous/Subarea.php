<?php

namespace app\admin\model\product\warehous;

use think\Model;


class Subarea extends Model
{

    

    

    // 表名
    protected $name = 'product_subarea';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'partition_type_text',
        'inventory_type_text',
        'status_text'
    ];
    

    
    public function getPartitionTypeList()
    {
        return ['标准' => __('标准'), '不良品' => __('不良品'), '退货区' => __('退货区'), '中转区' => __('中转区'), '缺货区' => __('缺货区')];
    }

    public function getInventoryTypeList()
    {
        return ['拣货' => __('拣货'), '存储' => __('存储'), '缺货' => __('缺货')];
    }

    public function getStatusList()
    {
        return ['可用' => __('可用'), '禁用' => __('禁用')];
    }


    public function getPartitionTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['partition_type']) ? $data['partition_type'] : '');
        $list = $this->getPartitionTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getInventoryTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['inventory_type']) ? $data['inventory_type'] : '');
        $list = $this->getInventoryTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
