<?php

namespace app\admin\model\product\warehous;

use think\Model;


class Warehous extends Model
{

    

    

    // 表名
    protected $name = 'product_warehouse';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'type_text',
        'operation_mode_text',
        'status_text'
    ];
    

    
    public function getTypeList()
    {
        return ['标准' => __('标准'), '中转' => __('中转')];
    }

    public function getOperationModeList()
    {
        return ['自营' => __('自营'), '第三方' => __('第三方')];
    }

    public function getStatusList()
    {
        return ['可用' => __('可用'), '不可用' => __('不可用')];
    }


    public function getTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['type']) ? $data['type'] : '');
        $list = $this->getTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getOperationModeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['operation_mode']) ? $data['operation_mode'] : '');
        $list = $this->getOperationModeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
