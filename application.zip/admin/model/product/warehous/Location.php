<?php

namespace app\admin\model\product\warehous;

use think\Model;


class Location extends Model
{

    

    

    // 表名
    protected $name = 'product_location';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'status_text',
        'temporary_text'
    ];
    

    
    public function getStatusList()
    {
        return ['可用' => __('可用'), '禁用' => __('禁用')];
    }

    public function getTemporaryList()
    {
        return ['是' => __('是'), '否' => __('否')];
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getTemporaryTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['temporary']) ? $data['temporary'] : '');
        $list = $this->getTemporaryList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
