<?php

namespace app\admin\model\product\setup;

use think\Model;


class ProductBrand extends Model
{

    

    

    // 表名
    protected $name = 'product_brand';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'is_enable_text'
    ];
    

    
    public function getIsEnableList()
    {
        return ['' => __(''), '是' => __('是'), '否' => __('否')];
    }


    public function getIsEnableTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_enable']) ? $data['is_enable'] : '');
        $list = $this->getIsEnableList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
