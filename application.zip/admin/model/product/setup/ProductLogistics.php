<?php

namespace app\admin\model\product\setup;

use think\Model;


class ProductLogistics extends Model
{

    

    

    // 表名
    protected $name = 'product_logistics';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'enable_text'
    ];
    

    
    public function getEnableList()
    {
        return ['是' => __('是'), '否' => __('否')];
    }


    public function getEnableTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['enable']) ? $data['enable'] : '');
        $list = $this->getEnableList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
