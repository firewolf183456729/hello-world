<?php

namespace app\admin\model\product\setup;

use think\Model;


class ProductSaleStatus extends Model
{

    

    

    // 表名
    protected $name = 'product_sale_status';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'purchase_proposal_text',
        'census_text',
        'status_text',
        'default_status_text'
    ];
    

    
    public function getPurchaseProposalList()
    {
        return ['是' => __('是'), '否' => __('否')];
    }

    public function getCensusList()
    {
        return ['是' => __('是'), '否' => __('否')];
    }

    public function getStatusList()
    {
        return ['可用' => __('可用'), '禁用' => __('禁用')];
    }

    public function getDefaultStatusList()
    {
        return ['否' => __('否'), '是' => __('是')];
    }


    public function getPurchaseProposalTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['purchase_proposal']) ? $data['purchase_proposal'] : '');
        $list = $this->getPurchaseProposalList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getCensusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['census']) ? $data['census'] : '');
        $list = $this->getCensusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getDefaultStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['default_status']) ? $data['default_status'] : '');
        $list = $this->getDefaultStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
