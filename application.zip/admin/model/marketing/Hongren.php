<?php

namespace app\admin\model\marketing;

use think\Model;


class Hongren extends Model
{

    

    

    // 表名
    protected $name = 'hongren';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'grade_text',
        'cooperation_progress_text',
        'gender_text'
    ];
    

    
    public function getGradeList()
    {
        return ['' => __(''), '一' => __('一'), '二' => __('二'), '三' => __('三'), '四' => __('四'), '五' => __('五')];
    }

    public function getCooperationProgressList()
    {
        return ['' => __(''), '联系中' => __('联系中'), '已寄送样品' => __('已寄送样品'), '已发布' => __('已发布')];
    }

    public function getGenderList()
    {
        return ['' => __(''), '男' => __('男'), '女' => __('女')];
    }


    public function getGradeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['grade']) ? $data['grade'] : '');
        $list = $this->getGradeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getCooperationProgressTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['cooperation_progress']) ? $data['cooperation_progress'] : '');
        $list = $this->getCooperationProgressList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getGenderTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['gender']) ? $data['gender'] : '');
        $list = $this->getGenderList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
