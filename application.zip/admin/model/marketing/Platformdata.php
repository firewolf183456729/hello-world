<?php

namespace app\admin\model\marketing;

use think\Model;


class Platformdata extends Model
{

    

    

    // 表名
    protected $name = 'platform_data';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    







}
