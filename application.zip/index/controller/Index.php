<?php

namespace app\index\controller;

use app\common\controller\Frontend;
use app\common\library\DingCallbackCrypto;
use think\Db;

class Index extends Frontend
{

    protected $noNeedLogin = '*';
    protected $noNeedRight = '*';
    protected $layout = '';

    public function index()
    {
        return $this->view->fetch();
    }
    /**
     * 计划任务
     */
    public function auto_rpa()
    {
        set_time_limit(0);
        ignore_user_abort(true);
        session_write_close();//session解锁
        $rpaIdList = [];
        $rpa_info = Db::table('fa_myrpa')->where('active',1)->select();
        // $rpa_id = $_POST['rpa_id'];
        for($i=0;$i<count($rpa_info);$i++){
            array_push($rpaIdList,$rpa_info[$i]['rpa_id']);
        }
        
        $startTime = date('Y-m-d 00:00:00',time()-24*60*60);
        $endTime = date('Y-m-d H:i:s',time());
//        echo $rpa_id.'--'.$startTime.'--'.$endTime;die;
        $headers = array(
            "Content-type:application/json;charset='utf-8'",
            "Accept:application/json",
            'token:3ed3eefa-8e04-4f9d-9945-f433b1ee3c3b'
        );
        $postData = array(
            "rpaIdList" => $rpaIdList,
            "startTime" => $startTime,
            "endTime"   => $endTime,
            "page"      => 1,
            "limit"     => 500
        );
        $ch =curl_init(); //初始化
        curl_setopt($ch , CURLOPT_URL,"https://rpa-server.ziniao.com/erp_report/list");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);//不做服务器认证
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,0);//不做客户端认证
        $result = curl_exec($ch);//执行访问
        //返回一个包含当前会话错误信息的字符串
        if($error=curl_error($ch)){
            echo json_encode($error);
        }
        curl_close($ch);//关闭curl，释放资源
//        echo $result;die;
        $result = json_decode($result,true);

        $rpa_datas = $result['data']['result'];
        for($i=0;$i<count($rpa_datas);$i++){
            //查重
            $runData = Db::table('fa_rpa_details')->where('rpa_id',$rpa_datas[$i]['rpaId'])->where('run_id',$rpa_datas[$i]['id'])->find();
            if($runData){
                continue;
            }
            $insertData['run_id'] = $rpa_datas[$i]['id'];
            $insertData['rpa_id'] = $rpa_datas[$i]['rpaId'];
            $insertData['url'] = urldecode($rpa_datas[$i]['url']);
            $insertData['run_name'] = urldecode($rpa_datas[$i]['name']);
            $insertData['rpa_name'] = $rpa_datas[$i]['rpaName'];
            $insertData['store_name'] = $rpa_datas[$i]['storeName'];
            $insertData['site_name'] = $rpa_datas[$i]['siteName'];
            $insertData['site_name_en'] = $rpa_datas[$i]['siteNameEn'];
            $insertData['platform_type'] = $rpa_datas[$i]['platformType'];
            $insertData['start_time'] = $rpa_datas[$i]['startTime'];
            $insertData['end_time'] = $rpa_datas[$i]['endTime'];
            $insertData['finish_time'] = date('Y-m-d H:i:s',strtotime($rpa_datas[$i]['finishTime']));
            $insertData['seller_id'] = $rpa_datas[$i]['sellerId'];
            $insertData['marketplace_id'] = $rpa_datas[$i]['marketplaceId'];
            Db::table('fa_rpa_details')->insertGetId($insertData);
        }
    }
    /**
     * 回调
     */
    public function ding_callBack()
    {
       
        $crypt = new DingCallbackCrypto('jJXkUv7i3Oe0AMPc9tQYT','5pcqVfo8gNBkFJPmvrvGiu5cayNRCh7aoMKjmNIl5hU', "dingegmttz4pbaypfwv1");
        $input = input('');
        $encryptMsg = $crypt->getDecryptMsg($input['msg_signature'], $input['timestamp'],  $input['nonce'], $input['encrypt']);
        Db::table('fa_test_content')->insertGetId(array('content'=>json_encode(input('')),'text'=>$encryptMsg,'created'=>date('Y-m-d H:i:s',time())));
        
        
        
        
        $result = $crypt->getEncryptedMap("success");
        return $result;
        
        
    }

}
